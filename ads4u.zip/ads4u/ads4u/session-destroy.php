<?php
session_start();
unset($_SESSION['email']);
unset($_SESSION['username']);
unset($_SESSION['verified']);
unset($_SESSION['profile_pic']);
unset($_SESSION['ads']);
unset($_SESSION['foru']);
unset($_SESSION['productid11']);
unset($_SESSION['rid']);

// session_unset();
// session_destroy();
header("location:login.php");
