<?php
include("includes/config.php");
if ((isset($_SESSION['ads'])) && (isset($_SESSION['foru']))) {

        include('includes/handler/session-handler.php');

        echo "
        <!DOCTYPE html>
        <html lang='en'>
        
        <head>
                <title>ClassyAds &mdash; Colorlib Website Template</title>
                <meta charset='utf-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
                <link rel='stylesheet' href='css/db-data.css'>
                <link href='https://fonts.googleapis.com/css?family=Nanum+Gothic:400,700,800' rel='stylesheet'>
                <link rel='stylesheet' href='fonts/icomoon/style.css'>

                <link rel='stylesheet' href='css/bootstrap.min.css'>
                <link rel='stylesheet' href='css/magnific-popup.css'>
                <link rel='stylesheet' href='css/jquery-ui.css'>
                <link rel='stylesheet' href='css/owl.carousel.min.css'>
                <link rel='stylesheet' href='css/owl.theme.default.min.css'>

                <link rel='stylesheet' href='css/bootstrap-datepicker.css'>

                <link rel='stylesheet' href='fonts/flaticon/font/flaticon.css'>

                <link rel='stylesheet' href='css/aos.css'>
                <link rel='stylesheet' href='css/rangeslider.css'>
                <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' />
                <link rel='stylesheet' href='css/footer.css' />
                <link rel='stylesheet' href='css/style.css'>

        </head>

        <body>

                <div class='site-wrap'>

                        <div class='site-mobile-menu'>
                                <div class='site-mobile-menu-header'>
                                        <div class='site-mobile-menu-close mt-3'>
                                                <span class='icon-close2 js-menu-toggle'></span>
                                        </div>
                                </div>
                                <div class='site-mobile-menu-body'></div>
                        </div>

                        <header class='site-navbar container py-0 bg-white' role='banner'>

                                <!-- <div class='container'> -->
                                <div class='row align-items-center'>

                                        <div class='col-6 col-xl-2'>
                                                <h1 style='margin-top: 9px;' class='mb-0 site-logo'>
                                                        <a style='font-size: 28px; ' href='index.php' class='text-black mb-0'>ADS<span class='text-primary'>4U</span>
                                                        </a>
                                                </h1>
                                        </div>
                                        <div class='col-12 col-md-10 d-none d-xl-block'>
                                                <nav class='site-navigation position-relative text-right' role='navigation'>
                                                        <ul class='site-menu js-clone-nav mr-auto d-none d-lg-block'>
                                                                <li><a href='index.php'>Home</a></li>
                                                                
                                                                <li><a href='contact.php'>Contact</a></li>

                                                                <li class='ml-xl-3 login'>
                                                                        <a id='login-session' href='login.php'><span class='border-left pl-xl-4'></span>Log In</a>
                                                                </li>
                                                                <li><a id='register-session' href='register.php'>Register</a></li>
                                                                <li><img id='image-session' style='height: 41px; width: 44px;  border-radius: 20px; cursor: pointer;' src='" . $_SESSION['profile_pic']  . " ' alt='profile_pic' /></li>

                                                                <li><a id='profile-session' href='profile.php'>" . $_SESSION['username'] . "</a></li>
                                                                <li><a id='logout-session' href='session-destroy.php'>Logout</a></li>

                                                                <li>
                                                                        <a id='post-add-session' class='cta'><span class='bg-primary text-white rounded'>+ Post an Ad</span></a>
                                                                </li>
                                                        </ul>
                                                </nav>
                                        </div>


                                        <div class='d-inline-block d-xl-none ml-auto py-3 col-6 text-right' style='position: relative; top: 3px;'>
                                                <a href='#' class='site-menu-toggle js-menu-toggle text-black'><span class='icon-menu h3'></span></a>
                                        </div>

                                </div>
                                <!-- </div> -->

                        </header>



                        <div class='site-blocks-cover inner-page-cover overlay' style='background-image: url(images/hero_1.jpg);' data-aos='fade' data-stellar-background-ratio='0.5'>
                                <div class='container'>
                                        <div class='row align-items-center justify-content-center text-center'>

                                                <div class='col-md-10' data-aos='fade-up' data-aos-delay='400'>


                                                        <div class='row justify-content-center mt-5'>
                                                                <div class='col-md-8 text-center'>
                                                                        <h1>Welcome to your Profile</h1>
                                                                </div>
                                                        </div>


                                                </div>
                                        </div>
                                </div>
                        </div>

                        <div class='site-section bg-light'>


                                ";
        if (isset($_SESSION['rid'])) {
                $rid = $_SESSION['rid'];

                $query = mysqli_query($con, "select * from product where registerid='$rid'");

                if (mysqli_num_rows($query) > 0) {
                        echo "<div id='p-detail'>Your Product Detail </div>";
                        echo "<div id='total_div' style='margin-bottom: 46px; margin-left: 42px;'>";
                        while ($result = mysqli_fetch_array($query)) {
                                if ($result['verified'] == 0) {
                                        echo "<div class='db-data' id='" . $result['pid'] . "' onclick='myfun(this.id)' >
                                                                        
                                                                                <img src='images/" . $result['pimage1'] . " ' />
                                                                                <label class='db-title'>" . $result['ptitle'] . "</label>
                                                                                <label class='db-price'><span class='rs'>Rs</span>" . $result['pprice'] . "</label>
                                                                                <span class='admin-message' style='margin-left: 23.5%; display: table;'>Your Product will be show on main page after approval by admin</span>


                                                                                
                                                                                
                                                </div> '";
                                } elseif ($result['verified'] == -1) {
                                        echo "<div class='db-data' id='" . $result['pid'] . "'  onclick='myfun(this.id)'>
                                                                                <img src='images/" . $result['pimage1'] . " ' />
                                                                                <label class='db-title'>" . $result['ptitle'] . "</label>
                                                                                <label class='db-price'><span class='rs'>Rs</span>" . $result['pprice'] . "</label>
                                                                                <span class='admin-message' style='margin-left: 9.5%; display: table;'>You have attached the illegal pictures,thats why this ad will not show on the main page.so please update your product</span>


                                                                                
                                                                                
                                                </div> ";
                                } else {
                                        echo "<div class='db-data' id='" . $result['pid'] . "'  onclick='myfun(this.id)'>
                                                                                <img src='images/" . $result['pimage1'] . " ' />
                                                                                <label class='db-title'>" . $result['ptitle'] . "</label>
                                                                                <label class='db-price'><span class='rs'>Rs</span>" . $result['pprice'] . "</label>
                                                                                <span class='admin-message' style='margin-left: 9.5%; display: table;'>Congratulation:Your Product has been approved by admin and posted on main page</span>


                                                                                
                                                                                
                                                </div> ";
                                }
                        }
                        echo "</div>";
                } else {
                        echo "<div class='surprise' style='margin-bottom: 63px;' >
                                                <img src='images/surprise.svg' atl='image is online thats why not showig'/>
                                                <label>You have not Post Anything yet so,</label>
                                                <a href='post.php' >Post Now</a>
                                                </div>
                                                ";
                }
        }

        echo "
        <footer class='footer-distributed'>

          <div class='footer-left'>
                <img src='images/mylogo.png'>
                <h3>About<span>ADS4U</span></h3>

                <p class='footer-links'>
                        <a href='index.php'>Home</a>
                        |
                       
                        <a href='contact.php'>Contact</a>
                </p>

                <p class='footer-company-name'>© 2019 ADS4U Learning Solutions Pvt. Ltd.</p>
        </div>

      <div class='footer-center'>
                <div>
                        <i class='fa fa-map-marker'></i>
                        <p><span>khudadad colony
                        ward#10 sher shah road</span>
                        multan, punjab </p>
                </div>
                <br>
                <div>
                        <i class='fa fa-phone'></i>
                        <p>+92 315-7960589</p>
                </div>
                <br>
                <div>
                        <i class='fa fa-envelope'></i>
                        <p><a href='#'>ads4u1122@gmail.com</a></p>
                </div>
      </div>
        <div class='footer-right'>
                <p class='footer-company-about'>
                <span>About the company</span>
              The Main Purpose of this website is to provide facility to both User.
              User who wants to Sell the Product and User who want to purchase the product.</p>
               
        </div>
      </footer>
       
        
        </div>
        <script src='js/jquery.js'></script>
        <script>
                function myfun(a) {


                        sessionStorage.setItem('value', a);


                        window.location.href = 'user_product_display.php';
                }
        </script>
        <script src='js/jquery-3.3.1.min.js'></script>
        <script src='js/jquery-migrate-3.0.1.min.js'></script>
        <script src='js/jquery-ui.js'></script>
        <script src='js/popper.min.js'></script>
        <script src='js/bootstrap.min.js'></script>
        <script src='js/owl.carousel.min.js'></script>
        <script src='js/jquery.stellar.min.js'></script>
        <script src='js/jquery.countdown.min.js'></script>
        <script src='js/jquery.magnific-popup.min.js'></script>
        <script src='js/bootstrap-datepicker.min.js'></script>
        <script src='js/aos.js'></script>
        <script src='js/rangeslider.min.js'></script>

        <script src='js/main.js'></script>

        </body>

        </html>";
} else {
        header("location:login.php");
}
