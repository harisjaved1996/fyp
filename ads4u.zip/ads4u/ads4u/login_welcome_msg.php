<?php
session_start();
if ((isset($_SESSION['ads'])) && (isset($_SESSION['foru']))) {

        echo "
       <html>

<head>
        <style>
                body {
                        background-color: black;
                        color: white;
                        margin-top: 10px;
                        margin: 0px;
                        padding: 0px;
                }

                #welcome_pic {
                        border-radius: 13px;
                        margin-top: 19px;
                        width: 230px;
                        height: 236px;
                        background-color: antiquewhite;
                }

                #dear {
                        font-size: 66px;
                        font-weight: bold;
                        letter-spacing: 10px;
                        font-family: monospace;
                }

                #user_name {
                        font-size: 66px;
                        letter-spacing: 5px;
                        word-spacing: 5px;
                        font-family: monospace;
                        font-weight: bold;
                        color: rgb(191, 230, 223);

                }

                #user_pic {
                        height: 229px;
                        width: 273px;
                        padding-bottom: 17px;
                        border-radius: 24px;
                }
        </style>
        <title>
                Welcome
        </title>
</head>

<body>
        <center>

                <img id='welcome_pic' src='images/welcome.png' alt='Welcome pic' /><br>

                <label id='dear'>Dear:</label>
                <label id='user_name'>" . $_SESSION['username'] . "</label><br>

                <img id='user_pic' src=" . $_SESSION['profile_pic'] . " alt='User_pic' />


        </center>
</body>

</html>";
        echo "<script>
        setTimeout(function() {
                window.location.href = 'profile.php';
        }, 3000)
</script>";
} else {

        echo "
       <html>

<head>
        <style>
                body {
                        background-color: black;
                        color: white;
                        margin-top: 10px;
                        margin: 0px;
                        padding: 0px;
                }

                #welcome_pic {
                        border-radius: 13px;
                        margin-top: 19px;
                        width: 250px;
                        height: 265px;
                        background-color: white;
                }

                #dear {
                        font-size: 66px;
                        font-weight: bold;
                        letter-spacing: 10px;
                        font-family: monospace;
                }

                
               
        </style>
        <title>
                Welcome
        </title>
</head>

<body>
        <center>

                <img id='welcome_pic' src='images/error.png' alt='error' /><br>

                <label id='dear'>Dear:Please Login First</label>
                


        </center>
</body>

</html>";
        echo "<script>
        setTimeout(function() {
                window.location.href = 'login.php';
        }, 3000)
</script>";
}
