--->htmlentities{
reference:htdocs/php_examples/mysqli_fetch_array.php
}
------>encrypted password
------>OOP

------>how to hide the url mean he does not reach on tha page by using url
--->real_escape string
--->important:agr login ho ga to personal pages display ho like profile.php etc..will use isset($_Session['etc'])
--->check karna han k agr same name ke image ajae to kia ho ga???
--->image code in javascript have to uderstand
--->mail 2 dfa send hte han...isse correct karna han
--->on key up function lgana post.php me text area pr or title par
--->note: this code is not run why -->(post_class.php)
line no 259
private function validate_cellnumber($cell_number)
{
if (preg_match("/[^0-9]/", $cell_number)) {
array_push($this->error_array, "Your cell number must be like this +[countrycode][cell-number]");
return;
}
}