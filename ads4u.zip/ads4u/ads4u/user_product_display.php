
<?php
include("includes/config.php");
if ((isset($_SESSION['ads'])) && (isset($_SESSION['foru']))) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if ($_POST['submit'] == 'Edit') {
                        header("location:update.php");
                } elseif ($_POST['submit'] == 'Remove') {
                        $productid = $_SESSION['productid11'];
                        $query = mysqli_query($con, "delete from product where pid='$productid '");
                        if (mysqli_affected_rows($con) > 0) {
                                header("location:profile.php");
                        } else {
                                die("check delete query in user_product_display in line 13");
                        }
                }
                // $productid = $_SESSION['productid11'];
                // die($productid);
        }
        echo "<script src='js/jquery.js'></script>";
        echo "<script>
        var x=sessionStorage.getItem('value');
        $.ajax({
             url:'user_product_display_ajax.php',
             type:'post',
             data:{product_id:x},
             success:function(data){
                     $('#details').html(data);
             }
        });
        </script>";




        echo "<html>

<head>

        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' />
         <link rel='stylesheet' href='css/user_product_display.css' />
        <link rel='stylesheet' href='css/post.css' />
</head>

<body>
        <div class='header'>
                <a href='#' onclick='confirm_arrow_fun()' class='logo'><span class='fa fa-arrow-circle-left' style='font-size: 30px;'></span></a>
                <a href='#' onclick='confirm_logo_fun()' class='logo'><span style='color: rgb(7, 8, 7);'>ADS</span><span style='color: rgb(13, 218, 13);'>4U</span></a>

        </div>
        <div style='text-align:center;  '  id='details'>
         
        </div>
        <footer class='footer-distributed'>

                <div class='footer-left'>
                        <img src='images/mylogo.png'>
                        <h3>About<span>ADS4U</span></h3>

                        <p class='footer-links'>
                                <a href='#'>Home</a>
                                |
                                <a href='#'>Blog</a>
                                |
                                <a href='#'>About</a>
                                |
                                <a href='#'>Contact</a>
                        </p>

                        <p class='footer-company-name'>© 2019 ADS4U Learning Solutions Pvt. Ltd.</p>
                </div>

                <div class='footer-center'>
                        <div>
                                <i class='fa fa-map-marker'></i>
                                <p><span>khudadad colony
                                                ward#10 sher shah road</span>
                                        multan, punjab </p>
                        </div>

                        <div>
                                <i class='fa fa-phone'></i>
                                <p>+92 315-7960589</p>
                        </div>
                        <div>
                                <i class='fa fa-envelope'></i>
                                <p><a href='#'>ads4u1122@gmail.com</a></p>
                        </div>
                </div>
                <div class='footer-right'>
                        <p class='footer-company-about'>
                                <span>About the company</span>
                                We offer training and skill building courses across Technology, Design, Management, Science and
                                Humanities.</p>
                        <div class='footer-icons'>
                                <a href='#'><i class='fa fa-facebook'></i></a>
                                <a href='#'><i class='fa fa-twitter'></i></a>
                                <a href='#'><i class='fa fa-instagram'></i></a>
                                <a href='#'><i class='fa fa-linkedin'></i></a>
                                <a href='#'><i class='fa fa-youtube'></i></a>
                        </div>
                </div>
        </footer>
        <script>
         function confirm_arrow_fun(){
                window.location.href='profile.php';
        }
        function confirm_logo_fun(){
                window.location.href='index.php';
        }
        </script>";
} else {
        header("location:login.php");
}
