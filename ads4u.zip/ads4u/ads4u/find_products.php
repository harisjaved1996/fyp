<?php
include("includes/config.php");
function setstring($s1)
{
      $s1 = strip_tags($s1);
      $s1 = str_replace(" ", "", $s1);
      $s1 = strtolower($s1);
      return $s1;
}
$country = setstring($_POST['u_country']);
$state = setstring($_POST['u_state']);
$city = setstring($_POST['u_city']);
$category = setstring($_POST['u_category']);
$subcategory = setstring($_POST['u_subcategory']);
// main part form here
// 5 pair combination
// 1st 5th combination
if ($country != "" && $state != "" && $city != "" && $category != "" && $subcategory != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];

      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and subcatid='$subcategory_id' and cid= '$country_id' and sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 4 pair combination
// 1st 4th combination
elseif ($country != "" && $state != "" && $city != "" && $category != "") {
      //country queries
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];
      //state queries
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      //city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and cid= '$country_id' and sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 2nd 4th combination
elseif ($country != "" && $city != "" && $category != "" && $subcategory != "") {
      //country queries
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      //city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and subcatid='$subcategory_id' and cid= '$country_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 3rd 4th combination
elseif ($country != "" && $state != "" && $category != "" && $subcategory != "") {
      //country queries
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      //state queries
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and subcatid='$subcategory_id' and cid= '$country_id' and sid='$state_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 4th 4th combination
elseif ($country != "" && $state != "" && $city != "" && $subcategory != "") {
      //country queries
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      //state queries
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      //city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where subcatid='$subcategory_id' and cid='$country_id' and sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 5h 4th combination
elseif ($state != "" && $city != "" && $category != "" && $subcategory != "") {
      //state queries
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      //city queries
      $city_query = mysqli_query($con, "select cityid from city where sid=$state_id and cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];

      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where catid=$category_id and subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid=$category_id and subcatid=$subcategory_id and sid=$state_id and cityid=$city_id  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 4th combination done
// 3 pair combination
// now starting to make the combinations of 3
// 1st combination of 3rd
elseif ($country != "" && $state != "" && $city) {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];

      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];

      // product queries
      $product_query = mysqli_query($con, "select * from product where  cid= '$country_id' and sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 
// 2nd combination of 3rd
elseif ($country != "" && $state != ""  && $category != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];


      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];

      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and cid='$country_id' and sid='$state_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 3rd combination of 3rd
elseif ($country != "" && $state != "" && $subcategory != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];

      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where  subcatid='$subcategory_id' and cid='$country_id' and sid='$state_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 4th combination of 3rd
elseif ($country != ""  && $city != "" && $category != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and cid='$country_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 5th combination of 3rd
elseif ($country != "" && $city != "" && $subcategory != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where  subcatid='$subcategory_id' and cid='$country_id'  and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 6th combination of 3rd
elseif ($country != "" && $category != "" && $subcategory != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];


      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and subcatid='$subcategory_id' and cid='$country_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 7th combination of 3rd
elseif ($state != "" && $city != "" && $category != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];

      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 8th combination of 3rd
elseif ($state != "" && $city != "" && $subcategory != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where subcatid='$subcategory_id' and sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 9th combination of 3rd
elseif ($state != "" && $category != "" && $subcategory != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and subcatid='$subcategory_id' and sid='$state_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 10th combination of 3rd
elseif ($city != "" && $category != "" && $subcategory != "") {
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where catid=$category_id and subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid=$category_id and subcatid=$subcategory_id and cityid=$city_id  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// end of 3 pair combination
// 2 pair combination
// 1st combination
elseif ($country != "" && $state != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];


      // product queries
      $product_query = mysqli_query($con, "select * from product where cid='$country_id' and sid='$state_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 2nd combination
elseif ($country != "" && $city != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];

      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];

      // product queries
      $product_query = mysqli_query($con, "select * from product where cid='$country_id' and cityid='$city_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 3rd combination
elseif ($country != "" && $category != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];


      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];

      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and cid='$country_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 4th combination
elseif ($country != "" && $subcategory != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];


      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where subcatid='$subcategory_id' and cid='$country_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 5th combination
elseif ($state != "" && $city != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];

      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where sid='$state_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 6th combination
elseif ($state != "" && $category != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and sid='$state_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 7th combination
elseif ($state != "" && $subcategory != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where subcatid='$subcategory_id' and sid='$state_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 8th combination
elseif ($city != "" && $category != "") {
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];

      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 9th combination
elseif ($city != "" && $subcategory != "") {
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where subcatid='$subcategory_id' and cityid='$city_id'  and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 10th combination
elseif ($category != "" && $subcategory != "") {
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and subcatid='$subcategory_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 1 pair combinations start
// 1st combination
elseif ($country != "") {
      // country_query
      $country_query = mysqli_query($con, "select cid from country where cname='$country'");
      $country_result = mysqli_fetch_array($country_query);
      $country_id = $country_result['cid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where cid='$country_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 2nd combination
elseif ($state != "") {
      // state_query
      $state_query = mysqli_query($con, "select sid from state where sname='$state'");
      $state_result = mysqli_fetch_array($state_query);
      $state_id = $state_result['sid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where sid='$state_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 3rd combination
elseif ($city != "") {
      // city queries
      $city_query = mysqli_query($con, "select cityid from city where cityname='$city'");
      $city_result = mysqli_fetch_array($city_query);
      $city_id = $city_result['cityid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where cityid='$city_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 4th combination
elseif ($category != "") {
      // category queries
      $category_query = mysqli_query($con, "select catid from category where category='$category'");
      $category_result = mysqli_fetch_array($category_query);
      $category_id = $category_result['catid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where catid='$category_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
}
// 5th combination
elseif ($subcategory != "") {
      // subcategory queries  
      $subcategory_query = mysqli_query($con, "select subcatid from subcategory where subcategory='$subcategory'");
      $subcategory_result = mysqli_fetch_array($subcategory_query);
      $subcategory_id = $subcategory_result['subcatid'];
      // product queries
      $product_query = mysqli_query($con, "select * from product where subcatid='$subcategory_id' and verified=1");
      $output = "<div id='products1' style='text-align:center;'>";
      if (mysqli_num_rows($product_query) != 0) {
            while ($product_result = mysqli_fetch_array($product_query)) {

                  $output .= " 
                        <div onclick='myfun(this.id)' id='" . $product_result['pid'] . "' class='my_products1' style='padding: 22px 51px;
                        margin-right: 20px;
                        text-align: center;
                        border: 1px solid gray;
                        cursor: pointer;
                        float: left;
                        margin-bottom: 20px;
                        background-color: rgb(247, 245, 245);
                        display: table;' >

                        <div class='images1'>
                        <img style=' width: 220px;
                        height: 250px;' src='images/" . $product_result['pimage1'] . "' alt='product_photo' />
                        </div>
                        <div class='pricee1'>
                        <span class='rs1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>RS</span>
                        <span class='price1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['pprice'] . "</span>
                        </div>
                        <div class='title1'>
                        <span class='title1' style='font-size: 20px;
                              color: black;
                              font-weight: bold;'>" . $product_result['ptitle'] . "</span>
                        </div>
                  </div>";
            }
      } else {
            $output .= " <span class='title1' style='font-size: 30px;
                        color: black;
                        font-weight: bold;'>NO AD FOUND</span>";
      }
      $output .= "</div>";

      echo $output;
} else {
      echo "<script>alert('Enter the data for search the ad')</script>";
}


// $query = mysqli_query($con, "select catid from category where category='$category'");
// $result = mysqli_fetch_array($query);
// $catid = $result['catid'];

// $query = mysqli_query($con, "select subcatid from subcategory where catid='$catid' and subcategory='$subcategory'");
// $result = mysqli_fetch_array($query);
// $subcatid = $result['subcatid'];

// $query1 = mysqli_query($con, "select userid from user where ucountry='$country' and ustate='$state' and ucity='$city'");
// $output = "<div id='products1' style='text-align:center;'>";
// if (mysqli_num_rows($query1) > 0) {

//       while ($result = mysqli_fetch_array($query1)) {

//             $userid = $result['userid'];

//             $query = mysqli_query($con, "select * from product where uid='$userid' and catid='$catid' and subcatid='$subcatid ' and verified=1");
//             if (mysqli_num_rows($query) > 0) {

//                   while ($result1 = mysqli_fetch_array($query)) {

//                         $output .= " 
//                         <div onclick='myfun(this.id)' id='" . $result1['pid'] . "' class='my_products1' style='padding: 22px 51px;
//                         margin-right: 20px;
//                         text-align: center;
//                         border: 1px solid gray;
//                         cursor: pointer;
//                         float: left;
//                         margin-bottom: 20px;
//                         background-color: rgb(247, 245, 245);
//                         display: table;' >

//                         <div class='images1'>
//                         <img style=' width: 220px;
//                         height: 250px;' src='images/" . $result1['pimage1'] . "' alt='product_photo' />
//                         </div>
//                         <div class='pricee1'>
//                         <span class='rs1' style='font-size: 20px;
//                               color: black;
//                               font-weight: bold;'>RS</span>
//                         <span class='price1' style='font-size: 20px;
//                               color: black;
//                               font-weight: bold;'>" . $result1['pprice'] . "</span>
//                         </div>
//                         <div class='title1'>
//                         <span class='title1' style='font-size: 20px;
//                               color: black;
//                               font-weight: bold;'>" . $result1['ptitle'] . "</span>
//                         </div>
//                   </div>";
//                   }
//             } else {
//                   $output = " <span class='title1' style='font-size: 30px;
//                         color: black;
//                         font-weight: bold;'>NO AD FOUND</span>";
//             }
//       }
// } else {
//       $output = " <span class='title1' style='font-size: 30px;
//                         color: black;
//                         font-weight: bold;'>NO AD FOUND</span>";
// }
// $output .= "</div>";

// echo $output;
