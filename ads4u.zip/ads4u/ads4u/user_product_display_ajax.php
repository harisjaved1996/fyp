<?php
include("includes/config.php");
if ((isset($_SESSION['ads'])) && (isset($_SESSION['foru']))) {
  $productid = $_POST['product_id'];
  $_SESSION['productid11'] = $productid;

  $query = mysqli_query($con, "select * from product where pid='$productid'");
  $result = mysqli_fetch_array($query);
  echo "
  <div id='product_details'>
        <center>
        <div id='p_details'>
            <table>
              <tr><td><span style='font-weight:bold;' id='product_condition'>Product Condition:</span>
              <span id='product_orignal_condtion'>{$result['con']}</span><br></td></tr>
              <tr><td><span style='font-weight:bold;' id='product_product'>Product Title:</span>
              <span id='product_orignal_title'>{$result['ptitle']}</span><br></td></tr>
              <tr><td><span style='font-weight:bold;' id='product_description'>Product Description:</span>
              <span id='product_orignal_description'>{$result['pdescription']}</span><br></td></tr>
              <tr><td><span style='font-weight:bold;' id='product_price'>Product Price:</span>
              <span id='product_orignal_price'>{$result['pprice']}</span><br></td></tr>
            </table>
           </div>
          <div id='product_images'>
            <h1 id='p_image'>Product Images</h1>
            <img style='height:200px;' src='images/{$result['pimage1']}' alt='pimage1' /> 
            <img style='height:200px;' src='images/{$result['pimage2']}' alt='pimage2' /> 
            <img style='height:200px;' src='images/{$result['pimage3']}' alt='pimage3' /> 
            <img style='height:200px;' src='images/{$result['pimage4']}' alt='pimage4' /> 
            <img style='height:200px;' src='images/{$result['pimage5']}' alt='pimage5' /> 
            <img style='height:200px;' src='images/{$result['pimage6']}' alt='pimage6' /> 
         </div> 
          <form method='post' action='user_product_display.php'>
            <div id='edit_remove'>
          
              <input type='submit' name='submit' value='Edit' />
              <input type='submit' name='submit' value='Remove' />
            </div>          
         </form>
         </center>
</div>";
} else {
  header("location:login.php");
}
