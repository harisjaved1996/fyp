<?php
include("includes/config.php");
include("includes/handler/session-handler.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <title>ADS4U </title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" href="css/myproducts.css">
  <link href="https://fonts.googleapis.com/css?family=Nanum+Gothic:400,700,800" rel="stylesheet" />
  <link rel="stylesheet" href="fonts/icomoon/style.css" />

  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/magnific-popup.css" />
  <link rel="stylesheet" href="css/jquery-ui.css" />
  <link rel="stylesheet" href="css/owl.carousel.min.css" />
  <link rel="stylesheet" href="css/owl.theme.default.min.css" />

  <link rel="stylesheet" href="css/bootstrap-datepicker.css" />

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css" />

  <link rel="stylesheet" href="css/aos.css" />
  <link rel="stylesheet" href="css/rangeslider.css" />

  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

  <link rel="stylesheet" href="css/footer.css" />
</head>

<body>
  <div class="site-wrap">
    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <header class="site-navbar container py-0 bg-white" role="banner">
      <!-- <div class="container"> -->
      <div class="row align-items-center">
        <div class="col-6 col-xl-2">
          <h1 style="margin-top: 9px;" class="mb-0 site-logo">
            <a style="font-size: 28px;" href="index.php" class="text-black mb-0">ADS<span class="text-primary">4U</span>
            </a>
          </h1>
        </div>
        <div class="col-12 col-md-10 d-none d-xl-block">
          <nav class="site-navigation position-relative text-right" role="navigation">
            <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
              <li class="active"><a href="index.php">Home</a></li>
              <!-- <li><a href="listings.php">Ads</a></li>
              <li class="has-children">
                <a href="about.php">About</a>
                <ul class="dropdown">
                  <li><a href="#">The Company</a></li>
                  <li><a href="#">The Leadership</a></li>
                  <li><a href="#">Philosophy</a></li>
                  <li><a href="#">Careers</a></li>
                </ul>
              </li>
              <li><a href="blog.php">Blog</a></li> -->
              <li><a href="contact.php">Contact</a></li>

              <li class="ml-xl-3 login">
                <a id="login-session" href="login.php"><span class="border-left pl-xl-4"></span>Log In</a>
              </li>

              <li><a id="register-session" href="register.php">Register</a></li>

              <li><img id="image-session" style="height: 41px; width: 44px;  border-radius: 20px; cursor: pointer;" src="<?php echo $_SESSION['profile_pic']; ?>" alt="profile_pic" /></li>
              <li><a id="profile-session" href="profile.php"><?php check_user_session(); ?></a></li>
              <li><a id="logout-session" href="session-destroy.php">Logout</a></li>

              <li>
                <a id="post-add-session" class="cta"><span class="bg-primary text-white rounded">+ Post an Ad</span></a>
              </li>
            </ul>
          </nav>
        </div>

        <div class="d-inline-block d-xl-none ml-auto py-3 col-6 text-right" style="position: relative; top: 3px;">
          <a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a>
        </div>
      </div>
      <!-- </div> -->
    </header>

    <div class="site-blocks-cover overlay" style="background-image: url(images/hero_2.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">
          <div class="col-md-12">
            <div class="row justify-content-center mb-4">
              <div class="col-md-8 text-center">
                <h1 class="" data-aos="fade-up">
                  Largest Classifieds In The World
                </h1>
                <p data-aos="fade-up" data-aos-delay="100">
                  You can buy, sell anything you want.
                </p>
              </div>
            </div>

            <div class="form-search-wrap" data-aos="fade-up" data-aos-delay="200">
              <form method="post">
                <div class="row align-items-center">

                  <div class="col-lg-12 mb-4 mb-xl-0 col-xl-4">
                    <select required class="form-control rounded" name="country" id="country">
                      <option value=''>Select Country</option>
                      <option value="Afganistan">Afghanistan</option>
                      <option value="Albania">Albania</option>
                      <option value="Algeria">Algeria</option>
                      <option value="American Samoa">American Samoa</option>
                      <option value="Andorra">Andorra</option>
                      <option value="Angola">Angola</option>
                      <option value="Anguilla">Anguilla</option>
                      <option value="Antigua & Barbuda">Antigua & Barbuda</option>
                      <option value="Argentina">Argentina</option>
                      <option value="Armenia">Armenia</option>
                      <option value="Aruba">Aruba</option>
                      <option value="Australia">Australia</option>
                      <option value="Austria">Austria</option>
                      <option value="Azerbaijan">Azerbaijan</option>
                      <option value="Bahamas">Bahamas</option>
                      <option value="Bahrain">Bahrain</option>
                      <option value="Bangladesh">Bangladesh</option>
                      <option value="Barbados">Barbados</option>
                      <option value="Belarus">Belarus</option>
                      <option value="Belgium">Belgium</option>
                      <option value="Belize">Belize</option>
                      <option value="Benin">Benin</option>
                      <option value="Bermuda">Bermuda</option>
                      <option value="Bhutan">Bhutan</option>
                      <option value="Bolivia">Bolivia</option>
                      <option value="Bonaire">Bonaire</option>
                      <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
                      <option value="Botswana">Botswana</option>
                      <option value="Brazil">Brazil</option>
                      <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                      <option value="Brunei">Brunei</option>
                      <option value="Bulgaria">Bulgaria</option>
                      <option value="Burkina Faso">Burkina Faso</option>
                      <option value="Burundi">Burundi</option>
                      <option value="Cambodia">Cambodia</option>
                      <option value="Cameroon">Cameroon</option>
                      <option value="Canada">Canada</option>
                      <option value="Canary Islands">Canary Islands</option>
                      <option value="Cape Verde">Cape Verde</option>
                      <option value="Cayman Islands">Cayman Islands</option>
                      <option value="Central African Republic">Central African Republic</option>
                      <option value="Chad">Chad</option>
                      <option value="Channel Islands">Channel Islands</option>
                      <option value="Chile">Chile</option>
                      <option value="China">China</option>
                      <option value="Christmas Island">Christmas Island</option>
                      <option value="Cocos Island">Cocos Island</option>
                      <option value="Colombia">Colombia</option>
                      <option value="Comoros">Comoros</option>
                      <option value="Congo">Congo</option>
                      <option value="Cook Islands">Cook Islands</option>
                      <option value="Costa Rica">Costa Rica</option>
                      <option value="Cote DIvoire">Cote DIvoire</option>
                      <option value="Croatia">Croatia</option>
                      <option value="Cuba">Cuba</option>
                      <option value="Curaco">Curacao</option>
                      <option value="Cyprus">Cyprus</option>
                      <option value="Czech Republic">Czech Republic</option>
                      <option value="Denmark">Denmark</option>
                      <option value="Djibouti">Djibouti</option>
                      <option value="Dominica">Dominica</option>
                      <option value="Dominican Republic">Dominican Republic</option>
                      <option value="East Timor">East Timor</option>
                      <option value="Ecuador">Ecuador</option>
                      <option value="Egypt">Egypt</option>
                      <option value="El Salvador">El Salvador</option>
                      <option value="Equatorial Guinea">Equatorial Guinea</option>
                      <option value="Eritrea">Eritrea</option>
                      <option value="Estonia">Estonia</option>
                      <option value="Ethiopia">Ethiopia</option>
                      <option value="Falkland Islands">Falkland Islands</option>
                      <option value="Faroe Islands">Faroe Islands</option>
                      <option value="Fiji">Fiji</option>
                      <option value="Finland">Finland</option>
                      <option value="France">France</option>
                      <option value="French Guiana">French Guiana</option>
                      <option value="French Polynesia">French Polynesia</option>
                      <option value="French Southern Ter">French Southern Ter</option>
                      <option value="Gabon">Gabon</option>
                      <option value="Gambia">Gambia</option>
                      <option value="Georgia">Georgia</option>
                      <option value="Germany">Germany</option>
                      <option value="Ghana">Ghana</option>
                      <option value="Gibraltar">Gibraltar</option>
                      <option value="Great Britain">Great Britain</option>
                      <option value="Greece">Greece</option>
                      <option value="Greenland">Greenland</option>
                      <option value="Grenada">Grenada</option>
                      <option value="Guadeloupe">Guadeloupe</option>
                      <option value="Guam">Guam</option>
                      <option value="Guatemala">Guatemala</option>
                      <option value="Guinea">Guinea</option>
                      <option value="Guyana">Guyana</option>
                      <option value="Haiti">Haiti</option>
                      <option value="Hawaii">Hawaii</option>
                      <option value="Honduras">Honduras</option>
                      <option value="Hong Kong">Hong Kong</option>
                      <option value="Hungary">Hungary</option>
                      <option value="Iceland">Iceland</option>
                      <option value="Indonesia">Indonesia</option>
                      <option value="India">India</option>
                      <option value="Iran">Iran</option>
                      <option value="Iraq">Iraq</option>
                      <option value="Ireland">Ireland</option>
                      <option value="Isle of Man">Isle of Man</option>
                      <option value="Israel">Israel</option>
                      <option value="Italy">Italy</option>
                      <option value="Jamaica">Jamaica</option>
                      <option value="Japan">Japan</option>
                      <option value="Jordan">Jordan</option>
                      <option value="Kazakhstan">Kazakhstan</option>
                      <option value="Kenya">Kenya</option>
                      <option value="Kiribati">Kiribati</option>
                      <option value="Korea North">Korea North</option>
                      <option value="Korea Sout">Korea South</option>
                      <option value="Kuwait">Kuwait</option>
                      <option value="Kyrgyzstan">Kyrgyzstan</option>
                      <option value="Laos">Laos</option>
                      <option value="Latvia">Latvia</option>
                      <option value="Lebanon">Lebanon</option>
                      <option value="Lesotho">Lesotho</option>
                      <option value="Liberia">Liberia</option>
                      <option value="Libya">Libya</option>
                      <option value="Liechtenstein">Liechtenstein</option>
                      <option value="Lithuania">Lithuania</option>
                      <option value="Luxembourg">Luxembourg</option>
                      <option value="Macau">Macau</option>
                      <option value="Macedonia">Macedonia</option>
                      <option value="Madagascar">Madagascar</option>
                      <option value="Malaysia">Malaysia</option>
                      <option value="Malawi">Malawi</option>
                      <option value="Maldives">Maldives</option>
                      <option value="Mali">Mali</option>
                      <option value="Malta">Malta</option>
                      <option value="Marshall Islands">Marshall Islands</option>
                      <option value="Martinique">Martinique</option>
                      <option value="Mauritania">Mauritania</option>
                      <option value="Mauritius">Mauritius</option>
                      <option value="Mayotte">Mayotte</option>
                      <option value="Mexico">Mexico</option>
                      <option value="Midway Islands">Midway Islands</option>
                      <option value="Moldova">Moldova</option>
                      <option value="Monaco">Monaco</option>
                      <option value="Mongolia">Mongolia</option>
                      <option value="Montserrat">Montserrat</option>
                      <option value="Morocco">Morocco</option>
                      <option value="Mozambique">Mozambique</option>
                      <option value="Myanmar">Myanmar</option>
                      <option value="Nambia">Nambia</option>
                      <option value="Nauru">Nauru</option>
                      <option value="Nepal">Nepal</option>
                      <option value="Netherland Antilles">Netherland Antilles</option>
                      <option value="Netherlands">Netherlands (Holland, Europe)</option>
                      <option value="Nevis">Nevis</option>
                      <option value="New Caledonia">New Caledonia</option>
                      <option value="New Zealand">New Zealand</option>
                      <option value="Nicaragua">Nicaragua</option>
                      <option value="Niger">Niger</option>
                      <option value="Nigeria">Nigeria</option>
                      <option value="Niue">Niue</option>
                      <option value="Norfolk Island">Norfolk Island</option>
                      <option value="Norway">Norway</option>
                      <option value="Oman">Oman</option>
                      <option value="Pakistan">Pakistan</option>
                      <option value="Palau Island">Palau Island</option>
                      <option value="Palestine">Palestine</option>
                      <option value="Panama">Panama</option>
                      <option value="Papua New Guinea">Papua New Guinea</option>
                      <option value="Paraguay">Paraguay</option>
                      <option value="Peru">Peru</option>
                      <option value="Phillipines">Philippines</option>
                      <option value="Pitcairn Island">Pitcairn Island</option>
                      <option value="Poland">Poland</option>
                      <option value="Portugal">Portugal</option>
                      <option value="Puerto Rico">Puerto Rico</option>
                      <option value="Qatar">Qatar</option>
                      <option value="Republic of Montenegro">Republic of Montenegro</option>
                      <option value="Republic of Serbia">Republic of Serbia</option>
                      <option value="Reunion">Reunion</option>
                      <option value="Romania">Romania</option>
                      <option value="Russia">Russia</option>
                      <option value="Rwanda">Rwanda</option>
                      <option value="St Barthelemy">St Barthelemy</option>
                      <option value="St Eustatius">St Eustatius</option>
                      <option value="St Helena">St Helena</option>
                      <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                      <option value="St Lucia">St Lucia</option>
                      <option value="St Maarten">St Maarten</option>
                      <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
                      <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
                      <option value="Saipan">Saipan</option>
                      <option value="Samoa">Samoa</option>
                      <option value="Samoa American">Samoa American</option>
                      <option value="San Marino">San Marino</option>
                      <option value="Sao Tome & Principe">Sao Tome & Principe</option>
                      <option value="Saudi Arabia">Saudi Arabia</option>
                      <option value="Senegal">Senegal</option>
                      <option value="Seychelles">Seychelles</option>
                      <option value="Sierra Leone">Sierra Leone</option>
                      <option value="Singapore">Singapore</option>
                      <option value="Slovakia">Slovakia</option>
                      <option value="Slovenia">Slovenia</option>
                      <option value="Solomon Islands">Solomon Islands</option>
                      <option value="Somalia">Somalia</option>
                      <option value="South Africa">South Africa</option>
                      <option value="Spain">Spain</option>
                      <option value="Sri Lanka">Sri Lanka</option>
                      <option value="Sudan">Sudan</option>
                      <option value="Suriname">Suriname</option>
                      <option value="Swaziland">Swaziland</option>
                      <option value="Sweden">Sweden</option>
                      <option value="Switzerland">Switzerland</option>
                      <option value="Syria">Syria</option>
                      <option value="Tahiti">Tahiti</option>
                      <option value="Taiwan">Taiwan</option>
                      <option value="Tajikistan">Tajikistan</option>
                      <option value="Tanzania">Tanzania</option>
                      <option value="Thailand">Thailand</option>
                      <option value="Togo">Togo</option>
                      <option value="Tokelau">Tokelau</option>
                      <option value="Tonga">Tonga</option>
                      <option value="Trinidad & Tobago">Trinidad & Tobago</option>
                      <option value="Tunisia">Tunisia</option>
                      <option value="Turkey">Turkey</option>
                      <option value="Turkmenistan">Turkmenistan</option>
                      <option value="Turks & Caicos Is">Turks & Caicos Is</option>
                      <option value="Tuvalu">Tuvalu</option>
                      <option value="Uganda">Uganda</option>
                      <option value="United Kingdom">United Kingdom</option>
                      <option value="Ukraine">Ukraine</option>
                      <option value="United Arab Erimates">United Arab Emirates</option>
                      <option value="United States of America">United States of America</option>
                      <option value="Uraguay">Uruguay</option>
                      <option value="Uzbekistan">Uzbekistan</option>
                      <option value="Vanuatu">Vanuatu</option>
                      <option value="Vatican City State">Vatican City State</option>
                      <option value="Venezuela">Venezuela</option>
                      <option value="Vietnam">Vietnam</option>
                      <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                      <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                      <option value="Wake Island">Wake Island</option>
                      <option value="Wallis & Futana Is">Wallis & Futana Is</option>
                      <option value="Yemen">Yemen</option>
                      <option value="Zaire">Zaire</option>
                      <option value="Zambia">Zambia</option>
                      <option value="Zimbabwe">Zimbabwe</option>

                    </select>

                  </div>
                  <div class="col-lg-12 mb-4 mb-xl-0 col-xl-3">
                    <div class="wrap-icon">

                      <input type="text" required id="state" class="form-control rounded" placeholder="Your State?" />

                    </div>
                  </div>
                  <div class="col-lg-12 mb-4 mb-xl-0 col-xl-3">
                    <div class="wrap-icon">

                      <input type="text" required id="city" class="form-control rounded" placeholder="Your City?" />

                    </div>
                  </div>
                  <div style="margin-top: 11px;" class="col-lg-12 mb-4 mb-xl-0 col-xl-4">
                    <select required class="form-control rounded" name="category" id="category" onchange="dynamic_select_box(this.id,'subcategory')">
                      <option value="" style="font-weight:bold;">Select Category</option>
                      <option value="mobile">MOBILE</option>
                      <option value="vehicles">Vehicles</option>
                      <option value="propertyforsale">Property For Sale</option>
                      <option value="propertyforrent">Property For Rent</option>
                      <option value="electroicsandhomeappliances">Electronics And Home Appliances</option>
                      <option value="bikes">Bikes</option>
                      <option value="buisnessindustrialagriculture">Buisness,Industrial & Agriculture</option>
                      <option value="services">Services</option>
                      <option value="jobs">Jobs</option>
                      <option value="animals">Animals</option>
                      <option value="furniturehomedecor">Furniture & home decor</option>
                      <option value="fashionbeauty">Fashion & Beauty</option>
                      <option value="bookssportshobbies">Books,Sports & Hobbies</option>
                      <option value="Kids">Kids</option>

                    </select>

                  </div>
                  <div style="margin-top: 11px;" class="col-lg-12 mb-4 mb-xl-0 col-xl-4">
                    <select required class="form-control rounded" name="subcategory" id="subcategory">
                      <option value="" style="font-weight:bold;">Select Sub-Category</option>

                    </select>

                  </div>



                  <div class="col-lg-12 col-xl-2 ml-auto text-right">
                    <input type="submit" id="submit" onclick="search_product(event)" class="btn btn-primary btn-block rounded" value="Search" />
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section bg-light">
      <div class="container">



        <div class="row">
          <div id="pro" class="col-12 block-13">


            <div id="products">
              <?php
              $query = mysqli_query($con, "select * from product where verified=1");
              if (mysqli_num_rows($query) > 0) {
                while ($result = mysqli_fetch_array($query)) {
                  echo "
                <div style='width:20%;box-sizing: border-box;'   class='my_products' id='{$result['pid']}'   onclick='myfun(this.id)'>
                  
                  <center>
                  <img src='images/" . $result['pimage1'] . "' alt='product_photo' />
                  <br>
                  
                  <span class='rs'>RS</span>
                  <span class='price'>" . $result['pprice'] . "</span>
                  
                  <br>
                  <span class='title'>" . $result['ptitle'] . "</span>
                  </center>
                </div>";
                }
              } else {
                echo "<span class='title1' style='font-size: 30px;
                        color: black; text-align:center;
                        font-weight: bold;'>NO AD FOUND</span>";
              }


              ?>
            </div>



          </div>
        </div>
      </div>
    </div>










    <footer class="footer-distributed">

      <div class="footer-left">
        <img src="images/mylogo.png">
        <h3>About<span>ADS4U</span></h3>

        <p class="footer-links">
          <a href="#">Home</a>
          |
          <!-- <a href="#">Blog</a>
          |
          <a href="#">About</a>
          | -->
          <a href="contact.php">Contact</a>
        </p>

        <p class="footer-company-name">© 2019 ADS4U Learning Solutions Pvt. Ltd.</p>
      </div>

      <div class="footer-center">
        <div>
          <i class="fa fa-map-marker"></i>
          <p><span>khudadad colony
              ward#10 sher shah road</span>
            multan, punjab </p>
        </div>
        <br>
        <div>
          <i class="fa fa-phone"></i>
          <p>+92 315-7960589</p>
        </div>
        <br>
        <div>
          <i class="fa fa-envelope"></i>
          <p><a href="#">ads4u1122@gmail.com</a></p>
        </div>
      </div>
      <div class="footer-right">
        <p class="footer-company-about">
          <span>About the company</span>
          The Main Purpose of this website is to provide facility to both User.
          User who wants to Sell the Product and User who want to purchase the product.</p>
        <!-- <div class="footer-icons">
          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-instagram"></i></a>
          <a href="#"><i class="fa fa-linkedin"></i></a>
          <a href="#"><i class="fa fa-youtube"></i></a>
        </div> -->
      </div>
    </footer>
  </div>

  <script>
    function myfun(a) {


      sessionStorage.setItem("value", a);

      window.location.href = 'product_owner.php';

    }

    function dynamic_select_box(s1, s2) {
      var s1 = document.getElementById(s1);

      var s2 = document.getElementById(s2);

      s2.innerHTML = "<option value='' style='font-weight:bold;'>Select Sub-Category</option>";

      if (s1.value == "mobile") {
        var optionarray = [

          "tablets|Tablets",
          "accessories|Accessories",
          "mobilephones|Mobile Phones",
        ];
      } else if (s1.value == "vehicles") {
        var optionarray = [

          "cars|Cars",
          "carsaccessories|Cars Accessories",
          "spareparts|Spare Parts",
          "busesvanstrucks|Buses,Vans & Trucks",
          "rickshawchingchi|Rickshaw and Chingchi",
          "othervehicles|Other Vehicles",
          "boats|Boats",
        ];
      } else if (s1.value == "propertyforsale") {
        var optionarray = [

          "landplots|Land & Plots",
          "houses|Houses",
          "apartmetsplots|Apartmets & Flats",
          "shopsofficescommercialspace|Shops,Offices,Commercial Space",
          "portionsfloors|Portions & Floors",
        ];
      } else if (s1.value == "propertyforrent") {
        var optionarray = [

          "houses1|Houses",
          "apartmetsplots1|Apartmets & Flats",
          "portionsfloors1|Portions & Floors",
          "shopsofficescommercialspace1|Shops,Offices,Commercial Space",
          "roommatespayingguests|Roommates & Payig Guests",
          "vacationrentalsguesthouses|Vacation Rentals-Guest Houses",
          "landplots1|Land & Plots",
        ];
      } else if (s1.value == "electroicsandhomeappliances") {
        var optionarray = [

          "computesaccessories|Computers And Accessories",
          "tvvideoaudio|TV - Video - Audio",
          "camerasaccessories|Cameras & Accessories",
          "gamesentertainment|Games & Entertainment",
          "otherhomeappliances|Other Home Appliances",
          "generatorsupspowersolutions| Generators, UPS & Power Solutions",
          "kitchenappliances| Kitchen Appliances",
          "accoolers| AC & Coolers",
          "fridgesfreezers| Fridges &amp; Freezers ",
          "washingmachinesdryers|Washing Machines &amp; Dryers",
        ];
      } else if (s1.value == "bikes") {
        var optionarray = [

          "motorcycles| Motorcycles",
          "spareparts|Spare Parts",
          "bicycles| Bicycles",
          "atvquads|ATV &amp; Quads",
          "scooters|Scooters",
        ];
      } else if (s1.value == "buisnessindustrialagriculture") {
        var optionarray = [

          "businessforsale| Business for Sale",
          "foodrestaurants| Food &amp; Restaurants",
          "tradeindustrial|  Trade &amp; Industrial",
          "constructionheavymachinery|Construction &amp; Heavy Machinery",
          "agriculture| Agriculture ",
          "otherbusinessindustry|  Other Business &amp; Industry ",
          "medicalpharma|  Medical &amp; Pharma  ",
        ];
      } else if (s1.value == "services") {
        var optionarray = [

          "educationclasses| Education &amp; Classes",
          "travelvisa|  Travel &amp; Visa",
          "carrental|Car Rental",
          "driverstaxi|Drivers &amp; Taxi",
          "webdevelopment|Web Development",
          "otherservices|Other Services",
          "electronicscomputerrepair|Electronics &amp; Computer Repair",
          "eventservices|Event Services ",
          "healthbeauty| Health &amp; Beauty",
          "maidsdomestichelp| Maids &amp; Domestic Help",
          "moverspackers| Movers &amp; Packers ",
          "homeofficerepair|  Home &amp; Office Repair",
          "cateringrestaurant|  Catering &amp; Restaurant",
          "farmfreshfood| Farm &amp; Fresh Food ",
        ];
      } else if (s1.value == "jobs") {
        var optionarray = [

          "online|Online",
          "marketing|Marketing",
          "advertisingpr|Advertising &amp; PR ",
          "education|Education",
          "customerservice|Customer Service ",
          "sales|Sales",
          "itnetworking|IT &amp; Networking",
          "hotelstourism|Hotels &amp; Tourism",
          "clericaladministration| Clerical &amp; Administration ",
          "humanresources|Human Resources ",
          "accountingfinance|Accounting &amp; Finance ",
          "manufacturing|Manufacturing ",
          "medical|Medical",
          "domesticstaff|Domestic Staff ",
          "parttime|Part - Time",
          "otherjobs|Other Jobs ",
        ];
      } else if (s1.value == "animals") {
        var optionarray = [

          "fishaquariums|Fish &amp; Aquariums ",
          "birds|Birds",
          "hensaseel| Hens &amp; Aseel ",
          "cats|cats",
          "dogs|Dogs ",
          "livestock|Livestock",
          "horses|Horses",
          "petfoodaccessories| Pet Food &amp; Accessories ",
          "otheranimals| Other Animals",
        ];
      } else if (s1.value == "furniturehomedecor") {
        var optionarray = [

          "sofachairs| Sofa &amp; Chairs ",
          "bedswardrobes| Beds &amp; Wardrobes ",
          "homedecoration| Home Decoration ",
          "tablesdining| Tables &amp; Dining ",
          "Gardenoutdoor| Garden &amp; Outdoor ",
          "paintingmirrors| Painting &amp; Mirrors ",
          "rugscarpets| Rugs &amp; Carpets ",
          "curtainsblinds| Curtains &amp; Blinds ",
          "officefurniture|Office Furniture",
          "otherhouseholditems| Other Household Items ",
        ];
      } else if (s1.value == "fashionbeauty") {
        var optionarray = [

          "accessories|Accessories",
          "clothes|Clothes",
          "footwear|Footwear",
          "jewellery|Jewellery",
          "makeup| Make Up ",
          "skinhair|Skin &amp; Hair ",
          "watches|Watches",
          "wedding|Wedding",
          "lawnpret|Lawn &amp; Pret ",
          "couture|Couture",
          "otherfashion|Other Fashion",
        ];
      } else if (s1.value == "bookssportshobbies") {
        var optionarray = [

          "booksmagazines|Books &amp; Magazines ",
          "musicalinstruments| Musical Instruments ",
          "sportsequipment| Sports Equipment ",
          "gymfitness| Gym &amp; Fitness ",
          "otherhobbies| Other Hobbies ",
        ];
      } else if (s1.value == "bookssportshobbies") {
        var optionarray = [

          "booksmagazines|Books &amp; Magazines ",
          "musicalinstruments| Musical Instruments ",
          "sportsequipment| Sports Equipment ",
          "gymfitness| Gym &amp; Fitness ",
          "otherhobbies| Other Hobbies ",
        ];
      } else if (s1.value == "Kids") {
        var optionarray = [

          "kidsfurniture| Kids Furniture ",
          "toys|Toys",
          "pramswalkers| Prams &amp; Walkers ",
          "swingsslides| Swings &amp; Slides ",
          "kidsbikes|Kids Bikes ",
          "kidsaccessories|Kids Accessories",
        ];
      }

      for (var option in optionarray) {
        var pair = optionarray[option].split("|");
        var newoption = document.createElement("option");
        newoption.value = pair[0];
        newoption.innerHTML = pair[1];
        s2.options.add(newoption);
      }
    }

    function search_product(event) {
      event.preventDefault();
      var country = $("#country").val();

      var state = $("#state").val();

      var city = $("#city").val();

      var category = $("#category").val();

      var subcategory = $("#subcategory").val();

      if (country == "" && state == "" && city == "" && category == "" && subcategory == "") {
        alert("Please Enter Data to Search The Ads ");
      } else {


        $("#products").hide();
        $.ajax({
          url: "find_products.php",
          type: "POST",
          data: {
            u_country: country,
            u_state: state,
            u_city: city,
            u_category: category,
            u_subcategory: subcategory
          },
          success: function(data) {
            console.log(data);
            $("#pro").html(data);
          }
        });
      }



      // $(document).ready(function() {



      // });




      // e.preventDefault();
      // var country = $("#country").val();
      // var state = $("#state").val();
      // var city = $("#city").val();
      // var category = $("#category").val();
      // var subcategory = $("#subcategory").val();
      // console.log(country.state.city.category.subcategory);



    }
  </script>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/rangeslider.min.js"></script>

  <script src="js/main.js"></script>
</body>

</html>