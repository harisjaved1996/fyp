<?php
include("includes/config.php");
if ((isset($_SESSION['ads'])) && (isset($_SESSION['foru']))) {
        include("includes/classes/post_class.php");
        $post_class = new post_class($con);
        include("includes/handler/post-handler.php");
        function set_val($s11)
        {
                if (isset($_POST[$s11])) {
                        return $_POST[$s11];
                }
        }
} else {
        header("location:login.php");
}
?>
<html>

<head>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

        <link rel="stylesheet" href="css/post.css" />
</head>

<body>
        <div class="header">
                <a href="#" onclick="confirm_arrow_fun()" class="logo"><span class="fa fa-arrow-circle-left" style="font-size: 30px;"></span></a>
                <a href="#" onclick="confirm_logo_fun()" class="logo"><span style="color: rgb(7, 8, 7);">ADS</span><span style="color: rgb(13, 218, 13);">4U</span></a>

        </div>
        </div>
        <section id="post-ad">
                <center>
                        <h1>POST YOUR AD</h1>
                </center>
        </section>

        <section id="form-section">
                <form action="post.php" method="POST" enctype="multipart/form-data">
                        <div class="form-class">
                                <h4>CHOOSE CATEGORY</h4>
                        </div>
                        <div class="form-class">
                                <select required name="category" id="category" onchange="dynamic_select_box(this.id,'subcategory')">
                                        <option value="" style="font-weight:bold;">Select Category</option>
                                        <option value="mobile">MOBILE</option>
                                        <option value="vehicles">Vehicles</option>
                                        <option value="propertyforsale">Property For Sale</option>
                                        <option value="propertyforrent">Property For Rent</option>
                                        <option value="electroicsandhomeappliances">Electronics And Home Appliances</option>
                                        <option value="bikes">Bikes</option>
                                        <option value="buisnessindustrialagriculture">Buisness,Industrial & Agriculture</option>
                                        <option value="services">Services</option>
                                        <option value="jobs">Jobs</option>
                                        <option value="animals">Animals</option>
                                        <option value="furniturehomedecor">Furniture & home decor</option>
                                        <option value="fashionbeauty">Fashion & Beauty</option>
                                        <option value="bookssportshobbies">Books,Sports & Hobbies</option>
                                        <option value="Kids">Kids</option>
                                </select><br>
                                <span class="hint">This field is mandatory</span>



                        </div>
                        <div class="form-class">
                                <h4>CHOOSE SUB-CATEGORY</h4>
                        </div>
                        <div class="form-class">
                                <select required name="subcategory" id="subcategory">
                                        <option value="" style="font-weight:bold;">Select Sub-Category</option>

                                </select><br>
                                <span class="hint">This field is mandatory</span>
                        </div>
                        <div class="form-class">
                                <h2>include Some Details</h2>
                        </div>

                        <div class="form-class">
                                <div id="condition">
                                        <h4>Condition</h4><br>
                                        <input type="radio" name="condition" id="new" required value="new"><label for="new">New</label></input>
                                        <input type="radio" name="condition" id="used" required value="used"><label for="used">Used</label></input>
                                </div>
                        </div>
                        <div class="form-class">
                                <div id="ad-title">
                                        <label for="title">Ad title</label><br>
                                        <input type="text" name="ad_title" required id="title" value="<?php echo set_val('ad_title');  ?>" /><br>
                                        <span class="hint">Mention the key features of your item (e.g. brand, model, age, type)</span>
                                        <?php echo $post_class->check_error("Your Ad-Title must contain between 3 and 20 characters");  ?>
                                </div>

                        </div>
                        <div class="form-class">
                                <div id="description">
                                        <label for="descript">Description</label><br>
                                        <textarea name="description" id="description-textarea" cols="30" rows="30" required><?php echo set_val('description'); ?></textarea><br>
                                        <span class=" hint">Include condition, features and reason for selling etc.Detailed information <br> about your product.Every information which you want to give about your <br> product.</span>
                                        <?php echo $post_class->check_error("Your Ad-description must contain between 10 ad 2000 characters");  ?>
                                </div>
                        </div>
                        <div class="form-class">
                                <div id="set-price">
                                        <label for="price">SET A PRICE</label><br>
                                        <div id="price-rs">
                                                <label for="price">Rs</label>
                                                <input type="number" name="price" required value="<?php echo set_val('price'); ?>" id="price" /><br>
                                                <span class="hint" style="margin-left: 33px;">This field is mandatory</span>

                                        </div>

                                </div>


                        </div>
                        <div class="form-class">
                                <div class="location">
                                        <h2>Confirm your location</h2>
                                        <div id="country">
                                                <label id="select-country" for="">Select your Country</label>
                                                <select id="country1" name="country">
                                                        <option value="Afganistan">Afghanistan</option>
                                                        <option value="Albania">Albania</option>
                                                        <option value="Algeria">Algeria</option>
                                                        <option value="American Samoa">American Samoa</option>
                                                        <option value="Andorra">Andorra</option>
                                                        <option value="Angola">Angola</option>
                                                        <option value="Anguilla">Anguilla</option>
                                                        <option value="Antigua & Barbuda">Antigua & Barbuda</option>
                                                        <option value="Argentina">Argentina</option>
                                                        <option value="Armenia">Armenia</option>
                                                        <option value="Aruba">Aruba</option>
                                                        <option value="Australia">Australia</option>
                                                        <option value="Austria">Austria</option>
                                                        <option value="Azerbaijan">Azerbaijan</option>
                                                        <option value="Bahamas">Bahamas</option>
                                                        <option value="Bahrain">Bahrain</option>
                                                        <option value="Bangladesh">Bangladesh</option>
                                                        <option value="Barbados">Barbados</option>
                                                        <option value="Belarus">Belarus</option>
                                                        <option value="Belgium">Belgium</option>
                                                        <option value="Belize">Belize</option>
                                                        <option value="Benin">Benin</option>
                                                        <option value="Bermuda">Bermuda</option>
                                                        <option value="Bhutan">Bhutan</option>
                                                        <option value="Bolivia">Bolivia</option>
                                                        <option value="Bonaire">Bonaire</option>
                                                        <option value="Bosnia & Herzegovina">Bosnia & Herzegovina</option>
                                                        <option value="Botswana">Botswana</option>
                                                        <option value="Brazil">Brazil</option>
                                                        <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                                                        <option value="Brunei">Brunei</option>
                                                        <option value="Bulgaria">Bulgaria</option>
                                                        <option value="Burkina Faso">Burkina Faso</option>
                                                        <option value="Burundi">Burundi</option>
                                                        <option value="Cambodia">Cambodia</option>
                                                        <option value="Cameroon">Cameroon</option>
                                                        <option value="Canada">Canada</option>
                                                        <option value="Canary Islands">Canary Islands</option>
                                                        <option value="Cape Verde">Cape Verde</option>
                                                        <option value="Cayman Islands">Cayman Islands</option>
                                                        <option value="Central African Republic">Central African Republic</option>
                                                        <option value="Chad">Chad</option>
                                                        <option value="Channel Islands">Channel Islands</option>
                                                        <option value="Chile">Chile</option>
                                                        <option value="China">China</option>
                                                        <option value="Christmas Island">Christmas Island</option>
                                                        <option value="Cocos Island">Cocos Island</option>
                                                        <option value="Colombia">Colombia</option>
                                                        <option value="Comoros">Comoros</option>
                                                        <option value="Congo">Congo</option>
                                                        <option value="Cook Islands">Cook Islands</option>
                                                        <option value="Costa Rica">Costa Rica</option>
                                                        <option value="Cote DIvoire">Cote DIvoire</option>
                                                        <option value="Croatia">Croatia</option>
                                                        <option value="Cuba">Cuba</option>
                                                        <option value="Curaco">Curacao</option>
                                                        <option value="Cyprus">Cyprus</option>
                                                        <option value="Czech Republic">Czech Republic</option>
                                                        <option value="Denmark">Denmark</option>
                                                        <option value="Djibouti">Djibouti</option>
                                                        <option value="Dominica">Dominica</option>
                                                        <option value="Dominican Republic">Dominican Republic</option>
                                                        <option value="East Timor">East Timor</option>
                                                        <option value="Ecuador">Ecuador</option>
                                                        <option value="Egypt">Egypt</option>
                                                        <option value="El Salvador">El Salvador</option>
                                                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                        <option value="Eritrea">Eritrea</option>
                                                        <option value="Estonia">Estonia</option>
                                                        <option value="Ethiopia">Ethiopia</option>
                                                        <option value="Falkland Islands">Falkland Islands</option>
                                                        <option value="Faroe Islands">Faroe Islands</option>
                                                        <option value="Fiji">Fiji</option>
                                                        <option value="Finland">Finland</option>
                                                        <option value="France">France</option>
                                                        <option value="French Guiana">French Guiana</option>
                                                        <option value="French Polynesia">French Polynesia</option>
                                                        <option value="French Southern Ter">French Southern Ter</option>
                                                        <option value="Gabon">Gabon</option>
                                                        <option value="Gambia">Gambia</option>
                                                        <option value="Georgia">Georgia</option>
                                                        <option value="Germany">Germany</option>
                                                        <option value="Ghana">Ghana</option>
                                                        <option value="Gibraltar">Gibraltar</option>
                                                        <option value="Great Britain">Great Britain</option>
                                                        <option value="Greece">Greece</option>
                                                        <option value="Greenland">Greenland</option>
                                                        <option value="Grenada">Grenada</option>
                                                        <option value="Guadeloupe">Guadeloupe</option>
                                                        <option value="Guam">Guam</option>
                                                        <option value="Guatemala">Guatemala</option>
                                                        <option value="Guinea">Guinea</option>
                                                        <option value="Guyana">Guyana</option>
                                                        <option value="Haiti">Haiti</option>
                                                        <option value="Hawaii">Hawaii</option>
                                                        <option value="Honduras">Honduras</option>
                                                        <option value="Hong Kong">Hong Kong</option>
                                                        <option value="Hungary">Hungary</option>
                                                        <option value="Iceland">Iceland</option>
                                                        <option value="Indonesia">Indonesia</option>
                                                        <option value="India">India</option>
                                                        <option value="Iran">Iran</option>
                                                        <option value="Iraq">Iraq</option>
                                                        <option value="Ireland">Ireland</option>
                                                        <option value="Isle of Man">Isle of Man</option>
                                                        <option value="Israel">Israel</option>
                                                        <option value="Italy">Italy</option>
                                                        <option value="Jamaica">Jamaica</option>
                                                        <option value="Japan">Japan</option>
                                                        <option value="Jordan">Jordan</option>
                                                        <option value="Kazakhstan">Kazakhstan</option>
                                                        <option value="Kenya">Kenya</option>
                                                        <option value="Kiribati">Kiribati</option>
                                                        <option value="Korea North">Korea North</option>
                                                        <option value="Korea Sout">Korea South</option>
                                                        <option value="Kuwait">Kuwait</option>
                                                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                        <option value="Laos">Laos</option>
                                                        <option value="Latvia">Latvia</option>
                                                        <option value="Lebanon">Lebanon</option>
                                                        <option value="Lesotho">Lesotho</option>
                                                        <option value="Liberia">Liberia</option>
                                                        <option value="Libya">Libya</option>
                                                        <option value="Liechtenstein">Liechtenstein</option>
                                                        <option value="Lithuania">Lithuania</option>
                                                        <option value="Luxembourg">Luxembourg</option>
                                                        <option value="Macau">Macau</option>
                                                        <option value="Macedonia">Macedonia</option>
                                                        <option value="Madagascar">Madagascar</option>
                                                        <option value="Malaysia">Malaysia</option>
                                                        <option value="Malawi">Malawi</option>
                                                        <option value="Maldives">Maldives</option>
                                                        <option value="Mali">Mali</option>
                                                        <option value="Malta">Malta</option>
                                                        <option value="Marshall Islands">Marshall Islands</option>
                                                        <option value="Martinique">Martinique</option>
                                                        <option value="Mauritania">Mauritania</option>
                                                        <option value="Mauritius">Mauritius</option>
                                                        <option value="Mayotte">Mayotte</option>
                                                        <option value="Mexico">Mexico</option>
                                                        <option value="Midway Islands">Midway Islands</option>
                                                        <option value="Moldova">Moldova</option>
                                                        <option value="Monaco">Monaco</option>
                                                        <option value="Mongolia">Mongolia</option>
                                                        <option value="Montserrat">Montserrat</option>
                                                        <option value="Morocco">Morocco</option>
                                                        <option value="Mozambique">Mozambique</option>
                                                        <option value="Myanmar">Myanmar</option>
                                                        <option value="Nambia">Nambia</option>
                                                        <option value="Nauru">Nauru</option>
                                                        <option value="Nepal">Nepal</option>
                                                        <option value="Netherland Antilles">Netherland Antilles</option>
                                                        <option value="Netherlands">Netherlands (Holland, Europe)</option>
                                                        <option value="Nevis">Nevis</option>
                                                        <option value="New Caledonia">New Caledonia</option>
                                                        <option value="New Zealand">New Zealand</option>
                                                        <option value="Nicaragua">Nicaragua</option>
                                                        <option value="Niger">Niger</option>
                                                        <option value="Nigeria">Nigeria</option>
                                                        <option value="Niue">Niue</option>
                                                        <option value="Norfolk Island">Norfolk Island</option>
                                                        <option value="Norway">Norway</option>
                                                        <option value="Oman">Oman</option>
                                                        <option value="Pakistan" selected>Pakistan</option>
                                                        <option value="Palau Island">Palau Island</option>
                                                        <option value="Palestine">Palestine</option>
                                                        <option value="Panama">Panama</option>
                                                        <option value="Papua New Guinea">Papua New Guinea</option>
                                                        <option value="Paraguay">Paraguay</option>
                                                        <option value="Peru">Peru</option>
                                                        <option value="Phillipines">Philippines</option>
                                                        <option value="Pitcairn Island">Pitcairn Island</option>
                                                        <option value="Poland">Poland</option>
                                                        <option value="Portugal">Portugal</option>
                                                        <option value="Puerto Rico">Puerto Rico</option>
                                                        <option value="Qatar">Qatar</option>
                                                        <option value="Republic of Montenegro">Republic of Montenegro</option>
                                                        <option value="Republic of Serbia">Republic of Serbia</option>
                                                        <option value="Reunion">Reunion</option>
                                                        <option value="Romania">Romania</option>
                                                        <option value="Russia">Russia</option>
                                                        <option value="Rwanda">Rwanda</option>
                                                        <option value="St Barthelemy">St Barthelemy</option>
                                                        <option value="St Eustatius">St Eustatius</option>
                                                        <option value="St Helena">St Helena</option>
                                                        <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                                                        <option value="St Lucia">St Lucia</option>
                                                        <option value="St Maarten">St Maarten</option>
                                                        <option value="St Pierre & Miquelon">St Pierre & Miquelon</option>
                                                        <option value="St Vincent & Grenadines">St Vincent & Grenadines</option>
                                                        <option value="Saipan">Saipan</option>
                                                        <option value="Samoa">Samoa</option>
                                                        <option value="Samoa American">Samoa American</option>
                                                        <option value="San Marino">San Marino</option>
                                                        <option value="Sao Tome & Principe">Sao Tome & Principe</option>
                                                        <option value="Saudi Arabia">Saudi Arabia</option>
                                                        <option value="Senegal">Senegal</option>
                                                        <option value="Seychelles">Seychelles</option>
                                                        <option value="Sierra Leone">Sierra Leone</option>
                                                        <option value="Singapore">Singapore</option>
                                                        <option value="Slovakia">Slovakia</option>
                                                        <option value="Slovenia">Slovenia</option>
                                                        <option value="Solomon Islands">Solomon Islands</option>
                                                        <option value="Somalia">Somalia</option>
                                                        <option value="South Africa">South Africa</option>
                                                        <option value="Spain">Spain</option>
                                                        <option value="Sri Lanka">Sri Lanka</option>
                                                        <option value="Sudan">Sudan</option>
                                                        <option value="Suriname">Suriname</option>
                                                        <option value="Swaziland">Swaziland</option>
                                                        <option value="Sweden">Sweden</option>
                                                        <option value="Switzerland">Switzerland</option>
                                                        <option value="Syria">Syria</option>
                                                        <option value="Tahiti">Tahiti</option>
                                                        <option value="Taiwan">Taiwan</option>
                                                        <option value="Tajikistan">Tajikistan</option>
                                                        <option value="Tanzania">Tanzania</option>
                                                        <option value="Thailand">Thailand</option>
                                                        <option value="Togo">Togo</option>
                                                        <option value="Tokelau">Tokelau</option>
                                                        <option value="Tonga">Tonga</option>
                                                        <option value="Trinidad & Tobago">Trinidad & Tobago</option>
                                                        <option value="Tunisia">Tunisia</option>
                                                        <option value="Turkey">Turkey</option>
                                                        <option value="Turkmenistan">Turkmenistan</option>
                                                        <option value="Turks & Caicos Is">Turks & Caicos Is</option>
                                                        <option value="Tuvalu">Tuvalu</option>
                                                        <option value="Uganda">Uganda</option>
                                                        <option value="United Kingdom">United Kingdom</option>
                                                        <option value="Ukraine">Ukraine</option>
                                                        <option value="United Arab Erimates">United Arab Emirates</option>
                                                        <option value="United States of America">United States of America</option>
                                                        <option value="Uraguay">Uruguay</option>
                                                        <option value="Uzbekistan">Uzbekistan</option>
                                                        <option value="Vanuatu">Vanuatu</option>
                                                        <option value="Vatican City State">Vatican City State</option>
                                                        <option value="Venezuela">Venezuela</option>
                                                        <option value="Vietnam">Vietnam</option>
                                                        <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                                                        <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                                                        <option value="Wake Island">Wake Island</option>
                                                        <option value="Wallis & Futana Is">Wallis & Futana Is</option>
                                                        <option value="Yemen">Yemen</option>
                                                        <option value="Zaire">Zaire</option>
                                                        <option value="Zambia">Zambia</option>
                                                        <option value="Zimbabwe">Zimbabwe</option>
                                                </select>
                                        </div>
                                        <div id="state">
                                                <label id="state" for="province">Your State</label><br>
                                                <input id="province" type="text" name="state" value="<?php echo set_val('state'); ?>" required /><br>
                                                <span class="hint ">This field is mandatory</span>
                                                <?php echo $post_class->check_error("State length must be greater than or equal to 5 charachters");  ?>
                                                <?php echo $post_class->check_error("Your state must contain only Alphabets");  ?>

                                        </div>
                                        <div id="city">
                                                <label for="city">Your City</label><br>
                                                <input id="city" type="text" name="city" value="<?php echo set_val('city'); ?>" required /><br>
                                                <span class="hint ">This field is mandatory</span>
                                                <?php echo $post_class->check_error("City length must be grater than or equal to 3 characters");  ?>
                                                <?php echo $post_class->check_error("Your city must contain only Alphabets");  ?>

                                                <div id="phone-number">
                                                        <label for="phone-number">Your Cell Number</label><br>
                                                        <input type="text" name="phone-number" id="phone-number" value="<?php echo set_val('phone-number'); ?>" required /><br>
                                                        <span class="hint">Fill this field like this &nbsp;&nbsp;&nbsp;&nbsp;+[country-code][cell-number]<br>e.g(+923157960589)</span>
                                                        <?php echo $post_class->check_error("Your cell number must be like this +[countrycode][cell-number]");  ?>
                                                </div>
                                        </div>

                                </div>

                                <div class="form-class" id="upload-images">
                                        <h2>Upload Images</h2>
                                        <ul class="images-ulist">
                                                <li class="images-list">
                                                        <input type="file" name="inpFile1" accept="image/*" required id="inpFile1" />
                                                        <div class="image-preview1" id="imagePreiew1">
                                                                <img src="" alt="imagePreiew" class="image-preview__image1" />
                                                                <span class="image-preview__default-text1">Image Preview</span>

                                                        </div>
                                                        <?php echo $post_class->check_error("1st Image type should be jpg,jpeg or png");  ?>
                                                </li>
                                                <li class="images-list">
                                                        <input type="file" name="inpFile2" accept="image/*" required id="inpFile2" />
                                                        <div class="image-preview2" id="imagePreiew2">
                                                                <img src="" alt="imagePreiew" class="image-preview__image2" />
                                                                <span class="image-preview__default-text2">Image Preview</span>
                                                        </div>
                                                        <?php echo $post_class->check_error("2nd Image type should be jpg,jpeg or png");  ?>
                                                </li>
                                                <li class="images-list">
                                                        <input type="file" name="inpFile3" accept="image/*" required id="inpFile3" />
                                                        <div class="image-preview3" id="imagePreiew3">
                                                                <img src="" alt="imagePreiew3" class="image-preview__image3" />
                                                                <span class="image-preview__default-text3">Image Preview</span>
                                                        </div>
                                                        <?php echo $post_class->check_error("3rd Image type should be jpg,jpeg or png");  ?>
                                                </li>
                                                <li class="images-list">
                                                        <input type="file" name="inpFile4" accept="image/*" required id="inpFile4" />
                                                        <div class="image-preview4" id="imagePreiew4">
                                                                <img src="" alt="imagePreiew4" class="image-preview__image4" />
                                                                <span class="image-preview__default-text4">Image Preview</span>
                                                        </div>
                                                        <?php echo $post_class->check_error("4th Image type should be jpg,jpeg or png");  ?>
                                                </li>
                                                <li class="images-list">
                                                        <input type="file" name="inpFile5" accept="image/*" required id="inpFile5" />
                                                        <div class="image-preview5" id="imagePreiew5">
                                                                <img src="" alt="imagePreiew" class="image-preview__image5" />
                                                                <span class="image-preview__default-text5">Image Preview</span>
                                                        </div>
                                                        <?php echo $post_class->check_error("5th Image type should be jpg,jpeg or png");  ?>
                                                </li>
                                                <li class="images-list">
                                                        <input type="file" name="inpFile6" accept="image/*" required id="inpFile6" />
                                                        <div class="image-preview6" id="imagePreiew6">
                                                                <img src="" alt="imagePreiew" class="image-preview__image6" />
                                                                <span class="image-preview__default-text6">Image Preview</span>
                                                        </div>
                                                        <?php echo $post_class->check_error("6th Image type should be jpg,jpeg or png");  ?>
                                                </li>


                                        </ul>


                                </div>


                                <div class="form-class" id="submit1">
                                        <div id="submit">
                                                <input id="sub" type="submit" name="submit" value="POST NOW">
                                        </div>

                                </div>




                </form>

        </section>
        <footer class="footer-distributed">

                <div class="footer-left">
                        <img src="images/mylogo.png">
                        <h3>About<span>ADS4U</span></h3>

                        <p class="footer-links">
                                <a href="index.php">Home</a>
                                |
                                <!-- <a href="#">Blog</a>
                                |
                                <a href="#">About</a>
                                | -->
                                <a href="contact.php">Contact</a>
                        </p>

                        <p class="footer-company-name">© 2019 ADS4U Learning Solutions Pvt. Ltd.</p>
                </div>

                <div class="footer-center">
                        <div>
                                <i class="fa fa-map-marker"></i>
                                <p><span>khudadad colony
                                                ward#10 sher shah road</span>
                                        multan, punjab </p>
                        </div>

                        <div>
                                <i class="fa fa-phone"></i>
                                <p>+92 315-7960589</p>
                        </div>
                        <div>
                                <i class="fa fa-envelope"></i>
                                <p><a href="#">ads4u1122@gmail.com</a></p>
                        </div>
                </div>
                <div class="footer-right">
                        <p class="footer-company-about">
                                <span>About the company</span>
                                The Main Purpose of this website is to provide facility to both User.
                                User who wants to Sell the Product and User who want to purchase the product..</p>
                        <!-- <div class="footer-icons">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-youtube"></i></a>
                        </div> -->
                </div>
        </footer>
        <script>
                function dynamic_select_box(s1, s2) {
                        var s1 = document.getElementById(s1);

                        var s2 = document.getElementById(s2);

                        s2.innerHTML = "<option value='' style='font-weight:bold;'>Select Sub-Category</option>";

                        if (s1.value == "mobile") {
                                var optionarray = [

                                        "tablets|Tablets",
                                        "accessories|Accessories",
                                        "mobilephones|Mobile Phones",
                                ];
                        } else if (s1.value == "vehicles") {
                                var optionarray = [

                                        "cars|Cars",
                                        "carsaccessories|Cars Accessories",
                                        "spareparts|Spare Parts",
                                        "busesvanstrucks|Buses,Vans & Trucks",
                                        "rickshawchingchi|Rickshaw and Chingchi",
                                        "othervehicles|Other Vehicles",
                                        "boats|Boats",
                                ];
                        } else if (s1.value == "propertyforsale") {
                                var optionarray = [

                                        "landplots|Land & Plots",
                                        "houses|Houses",
                                        "apartmetsplots|Apartmets & Flats",
                                        "shopsofficescommercialspace|Shops,Offices,Commercial Space",
                                        "portionsfloors|Portions & Floors",
                                ];
                        } else if (s1.value == "propertyforrent") {
                                var optionarray = [

                                        "houses1|Houses",
                                        "apartmetsplots1|Apartmets & Flats",
                                        "portionsfloors1|Portions & Floors",
                                        "shopsofficescommercialspace1|Shops,Offices,Commercial Space",
                                        "roommatespayingguests|Roommates & Payig Guests",
                                        "vacationrentalsguesthouses|Vacation Rentals-Guest Houses",
                                        "landplots1|Land & Plots",
                                ];
                        } else if (s1.value == "electroicsandhomeappliances") {
                                var optionarray = [

                                        "computesaccessories|Computers And Accessories",
                                        "tvvideoaudio|TV - Video - Audio",
                                        "camerasaccessories|Cameras & Accessories",
                                        "gamesentertainment|Games & Entertainment",
                                        "otherhomeappliances|Other Home Appliances",
                                        "generatorsupspowersolutions| Generators, UPS & Power Solutions",
                                        "kitchenappliances| Kitchen Appliances",
                                        "accoolers| AC & Coolers",
                                        "fridgesfreezers| Fridges &amp; Freezers ",
                                        "washingmachinesdryers|Washing Machines &amp; Dryers",
                                ];
                        } else if (s1.value == "bikes") {
                                var optionarray = [

                                        "motorcycles| Motorcycles",
                                        "spareparts|Spare Parts",
                                        "bicycles| Bicycles",
                                        "atvquads|ATV &amp; Quads",
                                        "scooters|Scooters",
                                ];
                        } else if (s1.value == "buisnessindustrialagriculture") {
                                var optionarray = [

                                        "businessforsale| Business for Sale",
                                        "foodrestaurants| Food &amp; Restaurants",
                                        "tradeindustrial|  Trade &amp; Industrial",
                                        "constructionheavymachinery|Construction &amp; Heavy Machinery",
                                        "agriculture| Agriculture ",
                                        "otherbusinessindustry|  Other Business &amp; Industry ",
                                        "medicalpharma|  Medical &amp; Pharma  ",
                                ];
                        } else if (s1.value == "services") {
                                var optionarray = [

                                        "educationclasses| Education &amp; Classes",
                                        "travelvisa|  Travel &amp; Visa",
                                        "carrental|Car Rental",
                                        "driverstaxi|Drivers &amp; Taxi",
                                        "webdevelopment|Web Development",
                                        "otherservices|Other Services",
                                        "electronicscomputerrepair|Electronics &amp; Computer Repair",
                                        "eventservices|Event Services ",
                                        "healthbeauty| Health &amp; Beauty",
                                        "maidsdomestichelp| Maids &amp; Domestic Help",
                                        "moverspackers| Movers &amp; Packers ",
                                        "homeofficerepair|  Home &amp; Office Repair",
                                        "cateringrestaurant|  Catering &amp; Restaurant",
                                        "farmfreshfood| Farm &amp; Fresh Food ",
                                ];
                        } else if (s1.value == "jobs") {
                                var optionarray = [

                                        "online|Online",
                                        "marketing|Marketing",
                                        "advertisingpr|Advertising &amp; PR ",
                                        "education|Education",
                                        "customerservice|Customer Service ",
                                        "sales|Sales",
                                        "itnetworking|IT &amp; Networking",
                                        "hotelstourism|Hotels &amp; Tourism",
                                        "clericaladministration| Clerical &amp; Administration ",
                                        "humanresources|Human Resources ",
                                        "accountingfinance|Accounting &amp; Finance ",
                                        "manufacturing|Manufacturing ",
                                        "medical|Medical",
                                        "domesticstaff|Domestic Staff ",
                                        "parttime|Part - Time",
                                        "otherjobs|Other Jobs ",
                                ];
                        } else if (s1.value == "animals") {
                                var optionarray = [

                                        "fishaquariums|Fish &amp; Aquariums ",
                                        "birds|Birds",
                                        "hensaseel| Hens &amp; Aseel ",
                                        "cats|cats",
                                        "dogs|Dogs ",
                                        "livestock|Livestock",
                                        "horses|Horses",
                                        "petfoodaccessories| Pet Food &amp; Accessories ",
                                        "otheranimals| Other Animals",
                                ];
                        } else if (s1.value == "furniturehomedecor") {
                                var optionarray = [

                                        "sofachairs| Sofa &amp; Chairs ",
                                        "bedswardrobes| Beds &amp; Wardrobes ",
                                        "homedecoration| Home Decoration ",
                                        "tablesdining| Tables &amp; Dining ",
                                        "Gardenoutdoor| Garden &amp; Outdoor ",
                                        "paintingmirrors| Painting &amp; Mirrors ",
                                        "rugscarpets| Rugs &amp; Carpets ",
                                        "curtainsblinds| Curtains &amp; Blinds ",
                                        "officefurniture|Office Furniture",
                                        "otherhouseholditems| Other Household Items ",
                                ];
                        } else if (s1.value == "fashionbeauty") {
                                var optionarray = [

                                        "accessories|Accessories",
                                        "clothes|Clothes",
                                        "footwear|Footwear",
                                        "jewellery|Jewellery",
                                        "makeup| Make Up ",
                                        "skinhair|Skin &amp; Hair ",
                                        "watches|Watches",
                                        "wedding|Wedding",
                                        "lawnpret|Lawn &amp; Pret ",
                                        "couture|Couture",
                                        "otherfashion|Other Fashion",
                                ];
                        } else if (s1.value == "bookssportshobbies") {
                                var optionarray = [

                                        "booksmagazines|Books &amp; Magazines ",
                                        "musicalinstruments| Musical Instruments ",
                                        "sportsequipment| Sports Equipment ",
                                        "gymfitness| Gym &amp; Fitness ",
                                        "otherhobbies| Other Hobbies ",
                                ];
                        } else if (s1.value == "bookssportshobbies") {
                                var optionarray = [

                                        "booksmagazines|Books &amp; Magazines ",
                                        "musicalinstruments| Musical Instruments ",
                                        "sportsequipment| Sports Equipment ",
                                        "gymfitness| Gym &amp; Fitness ",
                                        "otherhobbies| Other Hobbies ",
                                ];
                        } else if (s1.value == "Kids") {
                                var optionarray = [

                                        "kidsfurniture| Kids Furniture ",
                                        "toys|Toys",
                                        "pramswalkers| Prams &amp; Walkers ",
                                        "swingsslides| Swings &amp; Slides ",
                                        "kidsbikes|Kids Bikes ",
                                        "kidsaccessories|Kids Accessories",
                                ];
                        }

                        for (var option in optionarray) {
                                var pair = optionarray[option].split("|");
                                var newoption = document.createElement("option");
                                newoption.value = pair[0];
                                newoption.innerHTML = pair[1];
                                s2.options.add(newoption);
                        }
                }

                function confirm_arrow_fun() {
                        if (confirm("Are you sure you want to leave? Your progress will not be saved")) {
                                window.location.href = "profile.php";
                        }

                }

                function confirm_logo_fun() {
                        if (confirm("Are you sure you want to leave? Your progress will not be saved")) {
                                window.location.href = "index.php";
                        }

                }
                const inpFile1 = document.getElementById("inpFile1");

                const previewContainer1 = document.getElementById("imagePreiew1");

                const previewImage1 = previewContainer1.querySelector(
                        ".image-preview__image1"
                );

                const previewDefaultTExt1 = previewContainer1.querySelector(
                        ".image-preview__default-text1"
                );


                inpFile1.addEventListener("change", function() {
                        const file1 = this.files[0];
                        if (file1) {
                                const reader1 = new FileReader();
                                previewDefaultTExt1.style.display = "none";
                                previewImage1.style.display = "block";
                                reader1.addEventListener("load", function() {
                                        previewImage1.setAttribute("src", this.result);
                                });
                                reader1.readAsDataURL(file1);
                        } else {
                                previewDefaultTExt1.style.display = null;
                                previewImage1.style.display = null;
                                previewImage1.setAttribute("src", "");
                        }
                });
                const inpFile2 = document.getElementById("inpFile2");
                const previewContainer2 = document.getElementById("imagePreiew2");
                const previewImage2 = previewContainer2.querySelector(
                        ".image-preview__image2"
                );
                const previewDefaultTExt2 = previewContainer2.querySelector(
                        ".image-preview__default-text2"
                );
                inpFile2.addEventListener("change", function() {
                        const file2 = this.files[0];
                        if (file2) {
                                const reader2 = new FileReader();
                                previewDefaultTExt2.style.display = "none";
                                previewImage2.style.display = "block";
                                reader2.addEventListener("load", function() {
                                        previewImage2.setAttribute("src", this.result);
                                });
                                reader2.readAsDataURL(file2);
                        } else {
                                previewDefaultTExt2.style.display = null;
                                previewImage2.style.display = null;
                                previewImage2.setAttribute("src", "");
                        }
                });
                const inpFile3 = document.getElementById("inpFile3");
                const previewContainer3 = document.getElementById("imagePreiew3");
                const previewImage3 = previewContainer3.querySelector(
                        ".image-preview__image3"
                );
                const previewDefaultTExt3 = previewContainer3.querySelector(
                        ".image-preview__default-text3"
                );
                inpFile3.addEventListener("change", function() {
                        const file3 = this.files[0];
                        if (file3) {
                                const reader3 = new FileReader();
                                previewDefaultTExt3.style.display = "none";
                                previewImage3.style.display = "block";
                                reader3.addEventListener("load", function() {
                                        previewImage3.setAttribute("src", this.result);
                                });
                                reader3.readAsDataURL(file3);
                        } else {
                                previewDefaultTExt3.style.display = null;
                                previewImage3.style.display = null;
                                previewImage3.setAttribute("src", "");
                        }
                });
                const inpFile4 = document.getElementById("inpFile4");
                const previewContainer4 = document.getElementById("imagePreiew4");
                const previewImage4 = previewContainer4.querySelector(
                        ".image-preview__image4"
                );
                const previewDefaultTExt4 = previewContainer4.querySelector(
                        ".image-preview__default-text4"
                );
                inpFile4.addEventListener("change", function() {
                        const file4 = this.files[0];
                        if (file4) {
                                const reader4 = new FileReader();
                                previewDefaultTExt4.style.display = "none";
                                previewImage4.style.display = "block";
                                reader4.addEventListener("load", function() {
                                        previewImage4.setAttribute("src", this.result);
                                });
                                reader4.readAsDataURL(file4);
                        } else {
                                previewDefaultTExt4.style.display = null;
                                previewImage4.style.display = null;
                                previewImage4.setAttribute("src", "");
                        }
                });
                const inpFile5 = document.getElementById("inpFile5");
                const previewContainer5 = document.getElementById("imagePreiew5");
                const previewImage5 = previewContainer5.querySelector(
                        ".image-preview__image5"
                );
                const previewDefaultTExt5 = previewContainer5.querySelector(
                        ".image-preview__default-text5"
                );
                inpFile5.addEventListener("change", function() {
                        const file5 = this.files[0];
                        if (file5) {
                                const reader5 = new FileReader();
                                previewDefaultTExt5.style.display = "none";
                                previewImage5.style.display = "block";
                                reader5.addEventListener("load", function() {
                                        previewImage5.setAttribute("src", this.result);
                                });
                                reader5.readAsDataURL(file5);
                        } else {
                                previewDefaultTExt5.style.display = null;
                                previewImage5.style.display = null;
                                previewImage5.setAttribute("src", "");
                        }
                });
                const inpFile6 = document.getElementById("inpFile6");
                const previewContainer6 = document.getElementById("imagePreiew6");
                const previewImage6 = previewContainer6.querySelector(
                        ".image-preview__image6"
                );
                const previewDefaultTExt6 = previewContainer6.querySelector(
                        ".image-preview__default-text6"
                );
                inpFile6.addEventListener("change", function() {
                        const file6 = this.files[0];
                        if (file6) {
                                const reader6 = new FileReader();
                                previewDefaultTExt6.style.display = "none";
                                previewImage6.style.display = "block";
                                reader6.addEventListener("load", function() {
                                        previewImage6.setAttribute("src", this.result);
                                });
                                reader6.readAsDataURL(file6);
                        } else {
                                previewDefaultTExt6.style.display = null;
                                previewImage6.style.display = null;
                                previewImage6.setAttribute("src", "");
                        }
                });
        </script>
</body>

</html>