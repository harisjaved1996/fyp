<?php
//session_start();
include("includes/config.php");
include("includes/classes/account.php");
include("includes/classes/Constants.php");
$account = new Account($con);
// print_r($_SERVER);
/*

POSTArray ( [username] => djkfjkfdhjk@jkhjk.com [firstname] => djkfjkfdhjk@jkhjk.com [lastname] => djkfjkfdhjk@jkhjk.com [email] => djkfjkfdhjk@jkhjk.com [retypeemail] => djkfjkfdhjk@jk
*/
// echo $_SERVER["REQUEST_METHOD"];
include("includes/handler/register-handler.php");
include("includes/handler/session-handler.php");
//include("session-destroy.php");

function get_input_value($name)
{
  if (isset($_POST[$name])) {

    echo $_POST[$name];
  }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <title>ADS4U &mdash; Colorlib Website Template</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <link href="https://fonts.googleapis.com/css?family=Nanum+Gothic:400,700,800" rel="stylesheet" />
  <link rel="stylesheet" href="fonts/icomoon/style.css" />
  <link rel="stylesheet" href="css/imagepreview.css">
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/magnific-popup.css" />
  <link rel="stylesheet" href="css/jquery-ui.css" />
  <link rel="stylesheet" href="css/owl.carousel.min.css" />
  <link rel="stylesheet" href="css/owl.theme.default.min.css" />

  <link rel="stylesheet" href="css/bootstrap-datepicker.css" />

  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css" />

  <link rel="stylesheet" href="css/aos.css" />
  <link rel="stylesheet" href="css/rangeslider.css" />

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

  <link rel="stylesheet" href="css/footer.css" />
  <link rel="stylesheet" href="css/style.css" />

</head>


<body>

  <div class="site-wrap">
    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>

    <header class="site-navbar container py-0 bg-white" role="banner">
      <!-- <div class="container"> -->
      <div class="row align-items-center">
        <div class="col-6 col-xl-2">
          <h1 style="margin-top: 9px;" class="mb-0 site-logo">
            <a style="font-size: 28px; " href="index.php" class="text-black mb-0">ADS<span class="text-primary">4U</span>
            </a>
          </h1>
        </div>
        <div class="col-12 col-md-10 d-none d-xl-block">
          <nav class="site-navigation position-relative text-right" role="navigation">
            <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
              <li><a href="index.php">Home</a></li>
              <!-- <li><a href="listings.php">Ads</a></li>
              <li class="has-children">
                <a href="about.php">About</a>
                <ul class="dropdown">
                  <li><a href="#">The Company</a></li>
                  <li><a href="#">The Leadership</a></li>
                  <li><a href="#">Philosophy</a></li>
                  <li><a href="#">Careers</a></li>
                </ul>
              </li>
              <li><a href="blog.php">Blog</a></li> -->
              <li><a href="contact.php">Contact</a></li>

              <li class="ml-xl-3 login">
                <a id="login-session" href="login.php"><span class="border-left pl-xl-4"></span>Log In</a>
              </li>
              <li class="active"><a id="register-session" href="register.php">Register</a></li>
              <li><a id="profile-session" href="profile.php"><?php echo check_user_session(); ?></a></li>
              <li><img id="image-session" style="height: 41px; width: 44px;  border-radius: 20px; cursor: pointer;" src="<?php echo $_SESSION['profile_pic'] ?>" alt="" /></li>
              <li><a id="logout-session" href="session-destroy.php">Logout</a></li>

              <li>
                <a id="post-add-session" class="cta"><span class="bg-primary text-white rounded">+ Post an Ad</span></a>
              </li>
            </ul>
          </nav>
        </div>

        <div class="d-inline-block d-xl-none ml-auto py-3 col-6 text-right" style="position: relative; top: 3px;">
          <a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a>
        </div>
      </div>
      <!-- </div> -->
    </header>

    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/hero_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">
          <div class="col-md-10" data-aos="fade-up" data-aos-delay="400">
            <div class="row justify-content-center mt-5">
              <div class="col-md-8 text-center">
                <h1>Register</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 mb-5" data-aos="fade">
            <center>
              <h1>Registration Form</h1>
            </center>

            <form action="register.php" enctype="multipart/form-data" onsubmit="validation(event)" method="POST" class="p-5 bg-white" id="myForm">
              <div class="row form-group">
                <div class="col-md-12">

                  <label class="text-black" for="username">User Name</label>
                  <input type="text" id="username" onfocus="color_change()" placeholder="e.g..haris javed" name="username" value="<?php get_input_value('username'); ?>" required class="form-control" />
                  <div style="color:#DC143C; font-weight:bold;" id="error_username"></div>
                  <!-- <script>
                    document.getElementById("error_username").innerHTML = validdate_username("your username must be between 5 and 25 characters");
                  </script> -->
                  <?php echo $account->get_error("Username Start from Character"); ?>
                  <?php echo $account->get_error(Constants::$user_name_characters); ?>

                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">

                  <label class="text-black" for="firstname">First Name</label>
                  <input type="text" id="firstname" onclick="color_change()" name="firstname" placeholder="e.g..haris" value="<?php get_input_value('firstname'); ?>" required class="form-control" />
                  <div style="color:#DC143C; font-weight:bold;" id="error_firstname"></div>
                  <?php echo $account->get_error(Constants::$first_name_characters); ?>
                  <?php echo $account->get_error("First Name Can't Be Numeric"); ?>
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">

                  <label class="text-black" for="lastname">Last Name</label>
                  <input type="text" id="lastname" onclick="color_change()" name="lastname" required placeholder="e.g..javed" value="<?php get_input_value('lastname'); ?>" class="form-control" />
                  <div style="color:#DC143C; font-weight:bold;" id="error_lastname"></div>
                  <?php echo $account->get_error(Constants::$last_name_characters); ?>
                  <?php echo $account->get_error("Last Name Can't Be Numeric"); ?>

                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">


                  <input type="file" id="file" name="image_file" accept="image/*" required />

                  <div class="image-preview" id="imagePreiew">
                    <img src="" alt="imagePreiew" class="image-preview__image" />
                    <span class="image-preview__default-text">Image Preview</span>
                  </div>
                  <label style="color:#d600c5; font-weight:bold;" for="">NOTE:Upload your image(JPG/JPEG/PNG) here</label><br>
                  <?php echo  $account->get_error(Constants::$image_type); ?>

                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">

                  <label class="text-black" for="email">Email</label>
                  <input type="email" id="email" onclick="color_change()" name="email" placeholder="e.g..harisjaved@gmail.com" value="<?php get_input_value('email'); ?>" required class="form-control" />
                  <label id="gmail_id_use" style="color:#d600c5; font-weight:bold;">Note:Only use your Gmail account</label>
                  <div style="color:#DC143C; font-weight:bold;" id="error_email"></div>
                  <?php echo $account->get_error(Constants::$email_donot_match);
                  ?>
                  <?php echo $account->get_error(Constants::$email_invalid); ?>
                  <?php echo $account->get_error(Constants::$email_exists); ?>

                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="retypeemail">Re-type Email</label>
                  <input type="email" id="retypeemail" onclick="color_change()" name="retypeemail" placeholder="e.g..harisjaved@gmail.com" value="<?php get_input_value('retypeemail'); ?>" required class="form-control" />
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">

                  <label class="text-black" for="password">Password</label>
                  <input type="password" id="password" onclick="color_change()" placeholder="your passwod" name="password" required class="form-control" />
                  <span style="color:#DC143C; font-weight:bold;" id="error_password"></span>
                  <?php echo $account->get_error(Constants::$password_donot_match); ?>
                  <?php echo $account->get_error(Constants::$password_characters); ?>
                  <?php echo $account->get_error(Constants::$password_alpha_numeric); ?>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="retypepassword">Re-type Password</label>
                  <input type="password" id="retypepassword" onclick="color_change()" required placeholder="your password" name="retypepassword" class="form-control" />
                </div>
              </div>

              <div class="row form-group">
                <div class="col-12">
                  <p>Have an account? <a href="login.html">Log In</a></p>
                </div>
              </div>
              <center>
                <div class="row form-group">
                  <div class="col-md-12">
                    <input type="submit" name="registerbutton" value="Create Account" class="btn btn-primary py-2 px-4 text-white" />
                  </div>
                </div>
              </center>
            </form>
          </div>
        </div>
      </div>
    </div>

    <footer class="footer-distributed">

      <div class="footer-left">
        <img src="images/mylogo.png">
        <h3>About<span>ADS4U</span></h3>

        <p class="footer-links">
          <a href="#">Home</a>
          |
          <a href="#">Blog</a>
          |
          <a href="#">About</a>
          |
          <a href="#">Contact</a>
        </p>

        <p class="footer-company-name">© 2019 ADS4U Learning Solutions Pvt. Ltd.</p>
      </div>

      <div class="footer-center">
        <div>
          <i class="fa fa-map-marker"></i>
          <p><span>khudadad colony
              ward#10 sher shah road</span>
            multan, punjab </p>
        </div>
        <br>
        <div>
          <i class="fa fa-phone"></i>
          <p>+92 315-7960589</p>
        </div>
        <br>
        <div>
          <i class="fa fa-envelope"></i>
          <p><a href="#">ads4u1122@gmail.com</a></p>
        </div>
      </div>
      <div class="footer-right">
        <p class="footer-company-about">
          <span>About the company</span>
          We offer training and skill building courses across Technology, Design, Management, Science and
          Humanities.</p>
        <div class="footer-icons">
          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-instagram"></i></a>
          <a href="#"><i class="fa fa-linkedin"></i></a>
          <a href="#"><i class="fa fa-youtube"></i></a>
        </div>
      </div>
    </footer>
  </div>
  <script>
    // let input = document.querySelector("#username");
    // console.log(input);
    // input.addEventListener("focus", color_change);

    function color_change() {
      //var length = document.getElementsByClassName("form-control");
      // console.log(length);
      var x = document.getElementsByClassName("form-control");
      console.log(x);
      for (input of x) {
        input.style.color = "black";
      }
    }
  </script>
  <script src="javascript/register_imagepreview.js"></script>
  <script src="javascript/validation.js"></script>
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/rangeslider.min.js"></script>

  <script src="js/main.js"></script>
</body>

</html>