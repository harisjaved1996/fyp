<html>

<head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

        <link rel="stylesheet" href="css/post_css.css" />
</head>

<body>
        <div class="header">
                <a href="profile.php" class="logo"><span class="fa fa-arrow-circle-left" style="font-size: 30px;"></span></a>
                <a href="index.php" class="logo"><span style="color: rgb(7, 8, 7);">ADS</span><span style="color: rgb(13, 218, 13);">4U</span></a>

        </div>
        </div>
        <section id="post-ad">
                <center>
                        <h1>POST YOUR AD</h1>
                </center>
        </section>

        <section id="category">
                <h1>CHOOSE A CATEGORY</h1>
                <div class="navigation">
                        <ul>
                                <li class="has-sub">
                                        <a href="#">Mobile</a>
                                        <ul>
                                                <li class="has-sub">
                                                        <a href="mobile_attributes.php">Tablets</a>

                                                </li>
                                                <li><a href="mobile_attributes.php">Accessories</a></li>
                                                <li><a href="mobile_attributes.php">Mobile Phones</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">Vehicles</a>
                                        <ul>
                                                <li><a href="#">cars</a></li>
                                                <li><a href="#">cars accessories</a></li>
                                                <li><a href="#">spare parts</a></li>
                                                <li><a href="#">buses,vans & trucks</a></li>
                                                <li><a href="#">Rickshaw and chingchi</a></li>
                                                <li><a href="#">other vehicles</a></li>
                                                <li><a href="#">Boats</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">property for sale</a>
                                        <ul>
                                                <li><a href="#">Land & Plots</a></li>
                                                <li><a href="#">houses</a></li>
                                                <li><a href="#">apartments & plats</a></li>
                                                <li><a href="#">shops-offices-commercial space</a></li>
                                                <li><a href="#">portions & floors</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">property for rent</a>
                                        <ul>
                                                <li><a href="#">houses</a></li>
                                                <li><a href="#">apartments & flats</a></li>
                                                <li><a href="#">portions & floors</a></li>
                                                <li><a href="#">shops-offices-commercial space</a></li>
                                                <li><a href="#">land & plots</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">Electronics & home Appliances</a>
                                        <ul>
                                                <li><a href="#">Computers & Accessories</a></li>
                                                <li><a href="#">TV-video-audio</a></li>
                                                <li><a href="#">cameras & accessories</a></li>
                                                <li><a href="#">games & entertainment</a></li>
                                                <li><a href="#">other home appliances</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">Bikes</a>
                                        <ul>
                                                <li><a href="#">Motorcycles</a></li>
                                                <li><a href="#">spare parts</a></li>
                                                <li><a href="#">bicycles</a></li>
                                                <li><a href="#">atv & quads</a></li>
                                                <li><a href="#">scooters</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">Buisness,industrial & agriculture</a>
                                        <ul>
                                                <li><a href="#">buisness for sale</a></li>
                                                <li><a href="#">food and resturants</a></li>
                                                <li><a href="#">trade and industrial</a></li>
                                                <li><a href="#">construction and heavy machinery</a></li>
                                                <li><a href="#">agriculture</a></li>
                                                <li><a href="#">other buisness & industry</a></li>
                                                <li><a href="#">medical & pharma</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">services</a>
                                        <ul>
                                                <li><a href="#">other services</a></li>
                                                <li><a href="#">electronics & computer repairs</a></li>
                                                <li><a href="#">event services</a></li>
                                                <li><a href="#">healthy and beauty</a></li>
                                                <li><a href="#">maids & domestic help</a></li>
                                                <li><a href="#">movers & packers</a></li>
                                                <li><a href="#">home & office repair</a></li>
                                                <li><a href="#">catering & resturant</a></li>
                                                <li><a href="#">farm & fresh food</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">jobs</a>
                                        <ul>
                                                <li><a href="#">Education</a></li>
                                                <li><a href="#">customer service</a></li>
                                                <li><a href="#">sales</a></li>
                                                <li><a href="#">it & networking</a></li>
                                                <li><a href="#">hotels & tourism</a></li>
                                                <li><a href="#">clerical & administration</a></li>
                                                <li><a href="#">human resources</a></li>
                                                <li><a href="#">accounting & finance</a></li>
                                                <li><a href="#">manufacturing</a></li>
                                                <li><a href="#">medical</a></li>
                                                <li><a href="#">domestic staff</a></li>
                                                <li><a href="#">part-time</a></li>
                                                <li><a href="#">other jobs</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">Animals</a>
                                        <ul>
                                                <li><a href="#">livestock</a></li>
                                                <li><a href="#">horses</a></li>
                                                <li><a href="#">pet food & accessories</a></li>
                                                <li><a href="#">other animals</a></li>

                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">furniture & home decor</a>
                                        <ul>
                                                <li><a href="#">painting & mirrors</a></li>
                                                <li><a href="#">rugs & carpets</a></li>
                                                <li><a href="#">curtains & blinds</a></li>
                                                <li><a href="#">office furniture</a></li>
                                                <li><a href="#">other household items</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">fashion and beauty</a>
                                        <ul>
                                                <li><a href="#">skin & hair</a></li>
                                                <li><a href="#">watches</a></li>
                                                <li><a href="#">wedding</a></li>
                                                <li><a href="#">lawn & pret</a></li>
                                                <li><a href="#">couture</a></li>
                                                <li><a href="#">other Fashion</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">property for sale</a>
                                        <ul>
                                                <li><a href="#">Land & Plots</a></li>
                                                <li><a href="#">houses</a></li>
                                                <li><a href="#">apartments & plats</a></li>
                                                <li><a href="#">shops-offices-commercial space</a></li>
                                                <li><a href="#">portions & floors</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">books,sports & hobbies</a>
                                        <ul>
                                                <li><a href="#">books & magzines</a></li>
                                                <li><a href="#">musical instruments</a></li>
                                                <li><a href="#">sports equipments</a></li>
                                                <li><a href="#">gym & fitness</a></li>
                                                <li><a href="#">other hobbies</a></li>
                                        </ul>
                                </li>
                                <li class="has-sub">
                                        <a href="#">kids</a>
                                        <ul>
                                                <li><a href="#">kids furniture</a></li>
                                                <li><a href="#">toys</a></li>
                                                <li><a href="#">prams & walkers</a></li>
                                                <li><a href="#">swings & slides</a></li>
                                                <li><a href="#">kids bikes</a></li>
                                                <li><a href="#">kids accessories</a></li>
                                        </ul>
                                </li>
                        </ul>
                </div>
        </section>
        <footer class="footer-distributed">

                <div class="footer-left">
                        <img src="images/mylogo.png">
                        <h3>About<span>ADS4U</span></h3>

                        <p class="footer-links">
                                <a href="#">Home</a>
                                |
                                <a href="#">Blog</a>
                                |
                                <a href="#">About</a>
                                |
                                <a href="#">Contact</a>
                        </p>

                        <p class="footer-company-name">© 2019 ADS4U Learning Solutions Pvt. Ltd.</p>
                </div>

                <div class="footer-center">
                        <div>
                                <i class="fa fa-map-marker"></i>
                                <p><span>khudadad colony
                                                ward#10 sher shah road</span>
                                        multan, punjab </p>
                        </div>

                        <div>
                                <i class="fa fa-phone"></i>
                                <p>+92 315-7960589</p>
                        </div>
                        <div>
                                <i class="fa fa-envelope"></i>
                                <p><a href="#">ads4u1122@gmail.com</a></p>
                        </div>
                </div>
                <div class="footer-right">
                        <p class="footer-company-about">
                                <span>About the company</span>
                                We offer training and skill building courses across Technology, Design, Management, Science and Humanities.</p>
                        <div class="footer-icons">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-youtube"></i></a>
                        </div>
                </div>
        </footer>
</body>

</html>