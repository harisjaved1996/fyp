<?php
//session_start();

function check_user_session()
{
        if (isset($_SESSION['username'])) {
                echo $_SESSION['username'];
        }
}

if ((isset($_SESSION['email'])) && (isset($_SESSION['username']))) {

        //echo "<script>alert('set-part')</script>";
        //var_dump($_SESSION['email']);
        echo "<script src='js/jquery.js' ></script> ";
        echo "<script>$(document).ready(function(){
                    
                 $('#login-session').hide();
                 $('#register-session').hide();
                 $('#profile-session').show();
                 $('#logout-session').show();
                 $('#image-session').show();
                 
                 $('#post-add-session').css('cursor','pointer');
                 $('#post-add-session').click(function(){
                        window.location.href = 'post.php';
                 });
                 $('#image-session').click(function(){
                         window.location.href = 'profile.php';
                 });
                

                 
        });
        </script>";
} else {
        // echo "<script>alert('else-part')</script>";
        //var_dump($_SESSION['email']);

        echo "<script src='js/jquery.js' ></script> ";
        echo "<script>$(document).ready(function(){
                            
                $('#login-session').show();
                $('#register-session').show();
                $('#profile-session').hide();
                $('#logout-session').hide();
                $('#image-session').hide();
                $('#post-add-session').css('cursor','pointer');
                $('#post-add-session').click(function(){
                        window.location.href = 'login.php';
                 });
        });
        </script>";
}
