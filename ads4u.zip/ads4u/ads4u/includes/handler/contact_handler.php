<?php
function set_string1($val)
{
        $val = str_replace(" ", "", $val);
        $val = strip_tags($val);
        return $val;
}
function set_string($val)
{
        $val = strip_tags($val);
        return $val;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {


        $fname = set_string1($_POST['fname']);
        $lname = set_string1($_POST['lname']);
        $email = set_string($_POST['email']);
        $subject = set_string($_POST['subject']);
        $message = set_string($_POST['message']);
        $is_successfull = $contact->validate_contact($fname, $lname, $email, $subject, $message);
        if ($is_successfull) {
                $to = "ads4u1122@gmail.com";
                $subject = "From : $email";
                $header = "From : $email";


                if (mail(
                        $to,
                        $subject,
                        $message,
                        $header




                )) {

                        echo "<script>alert('Congratulation you message has bee sent successfully');
                                window.location.href='contact.php';
                                </script>";
                } else {
                        echo "your Internet Connection is bad";
                }
        }
}
