<?php
//login button

function set_value($myemail)
{
        if (isset($_POST[$myemail])) {
                echo $_POST[$myemail];
        }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //$error_array = array();

        $email = $_POST['myemail'];
        $password = $_POST['mypassword'];
        $is_succesffull = $login->login_value($email, $password);
        if ($is_succesffull == true) {
                $_SESSION['email'] = $email;
                header("location:login_welcome_msg.php");
        }
}
/*
function get_error($error)
{
        //global $error_array;
        if (!in_array($error, $error_array)) {
                $error = "";
        }
        return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
}

function set_value($myemail)
{
        if (isset($_POST[$myemail])) {
                echo $_POST[$myemail];
        }
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //$error_array = array();

        $email = $_POST['myemail'];
        $password = $_POST['mypassword'];
        $password =  password_hash($password, PASSWORD_DEFAULT);


        $query = mysqli_query($con, "SELECT * FROM register WHERE email='$email' ");

        $rows = mysqli_num_rows($query);

        if ($rows != 0) {

                while ($result = mysqli_fetch_array($query)) {
                        $email = $result['email'];
                        $username = $result['username'];
                        $profile_pic = $result['profilepic'];
                }
                $_SESSION['email'] = $email;
                $_SESSION['username'] = $username;
                $_SESSION['profile_pic'] = $profile_pic;
                header("location:profile.php");
        } else {

                array_push($error_arrray, "Invalid username or passsword");
        }
}
*/
