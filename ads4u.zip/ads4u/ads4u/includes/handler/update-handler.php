<?php

function set_string2($s1)
{
        $s1 = strip_tags($s1);
        $s1 = strtolower($s1);
        $s1 = str_replace(" ", "", $s1);
        return $s1;
}
function set_string1($s1)
{
        $s1 = strip_tags($s1);
        $s1 = str_replace(" ", "", $s1);

        return $s1;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $category = $_POST['category'];
        $sub_category = $_POST['subcategory'];
        $condition = $_POST['condition'];
        $ad_title = set_string2($_POST['ad_title']);
        $description = set_string2($_POST['description']);
        $price = $_POST['price'];
        $country = set_string2($_POST['country']);
        $state = set_string2($_POST['state']);
        $city = set_string2($_POST['city']);
        $phone_number = set_string1($_POST['phone-number']);




        //echo "<script>console.log('Debug Objects: " .  $phone_number . "' );</script>";

        /* */
        $successfull_post = $update_class->postattr($category, $sub_category, $condition, $ad_title, $description, $price, $country, $state, $city, $phone_number);
        if ($successfull_post == true) {
                //after successfull 
                header("location:profile.php");
        }
}
