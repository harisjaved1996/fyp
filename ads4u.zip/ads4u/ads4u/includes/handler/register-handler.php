<?php
function set_username($inputtext)
{
	$inputtext = strip_tags($inputtext);  //it remove the html tags if written by user in input
	$inputtext = str_replace(" ", "", $inputtext); //if the string contain space then it convert the space into empty string written in variable input text
	return $inputtext;
}
function set_password($inputtext)
{
	$inputtext = strip_tags($inputtext);
	return $inputtext;
}
function set_string($inputtext)
{
	$inputtext = strip_tags($inputtext);
	$inputtext = str_replace(" ", "", $inputtext);
	$inputtext = ucfirst(strtolower($inputtext)); //first convert the string into lover cast then convert the 1st letter into uppercase
	return $inputtext;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = set_username($_POST['username']);
	$firstname = set_string($_POST['firstname']);
	$lastname = set_string($_POST['lastname']);
	$email = set_string($_POST['email']);
	$retypeemail = set_string($_POST['retypeemail']);
	$password = set_password($_POST['password']);
	$retypepassword = set_password($_POST['retypepassword']);
	$vkey = rand(100000, 999999); //verificaton key..
	//$vkey= md5(time()); md5 give 32 characters
	//$vkey=substr($vkey,0,6)  store only 6 charcters
	$is_successfull = $account->register($username, $firstname, $lastname, $email, $retypeemail, $password, $retypepassword, $vkey);
	if ($is_successfull == true) {
		$_SESSION['firstname'] = $firstname;
		$_SESSION['email'] = $email;
		$_SESSION['vkey'] = $vkey;
		$_SESSION['ads'] = 'haris';
		$_SESSION['foru'] = 'javed';
		function sendmail()
		{

			$to = $_SESSION['email'];


			$sub = "Verification Code From ADS4U";

			$msg = "Dear " . $_SESSION['firstname'] . " Your Verification Code is:" . $_SESSION['vkey'];

			if (mail($to, $sub, $msg)) {
				return;
			} else {
				echo "your Internet Connection is bad";
			}
		}
		sendmail();

		header("location:verification_msg.php");
		//$_SESSION['username'] = $username;



		// print_r($_SESSION['username']);
		// die("here is working");
		// header("location:del.php");


		//header("location:register.php");
		//echo "<script> setTimeout(function(){window.location.href = 'index.html';}, 8000)</script>";
		//header("Location:index.html");
	}
}
