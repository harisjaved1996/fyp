<?php
session_start();
//ob_start();
$timezone = date_default_timezone_set("Asia/Karachi");

$con = mysqli_connect("localhost", "root", "", "ads4u");


if (mysqli_connect_errno()) {
        echo "Failed to connect:" . mysqli_connect_errno();
}
