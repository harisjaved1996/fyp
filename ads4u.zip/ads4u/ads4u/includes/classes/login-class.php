<?php
class Login
{
        private $con;
        private $error_array;
        public function __construct($con)
        {
                $this->con = $con;
                $this->error_array = array();
        }
        public function get_error($error)
        {
                //global $error_array;
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
        }
        public function login_value($em, $pas)
        {
                $query = mysqli_query($this->con, "SELECT * FROM register WHERE email='$em' ");
                if (mysqli_num_rows($query) > 0) {

                        //while ($result = mysqli_fetch_array($query)) {
                        $result = mysqli_fetch_array($query);
                        $email = $result['email'];
                        $username = $result['username'];
                        $password = $result['password'];
                        $verified = $result['verified'];
                        $firstname = $result['firstname'];
                        $profile_pic = $result['profilepic'];
                        $vkey = $result['vkey'];

                        if (password_verify($pas, $password)) {
                                if ($verified == 1) {
                                        $_SESSION['email'] = $email;
                                        $_SESSION['username'] = $username;
                                        $_SESSION['rid'] = $result['id'];
                                        $_SESSION['verified'] = $verified;
                                        $_SESSION['profile_pic'] = $profile_pic;
                                        $_SESSION['ads'] = 'haris';
                                        $_SESSION['foru'] = 'javed';

                                        return true;
                                } else {

                                        $_SESSION['email'] = $email;
                                        $_SESSION['username'] = $username;
                                        $_SESSION['firstname'] = $firstname;
                                        $_SESSION['profile_pic'] = $profile_pic;
                                        $_SESSION['vkey'] = $vkey;
                                        function sendmail()
                                        {

                                                $to = $_SESSION['email'];


                                                $sub = "Verification Code From ADS4U";

                                                $msg = "Dear " . $_SESSION['firstname'] . " Your Verification Code is:" . $_SESSION['vkey'];

                                                if (mail($to, $sub, $msg)) {
                                                        return;
                                                } else {
                                                        echo "your Internet Connection is bad";
                                                }
                                        }
                                        sendmail();
                                        header("location:verification_msg.php");
                                }
                        } else {
                                array_push($this->error_array, "Invalid email or passsword");
                        }
                        //}

                        //header("location:profile.php");
                } else {

                        array_push($this->error_array, "Invalid email or passsword");
                }
        }
}
