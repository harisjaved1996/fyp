
<?php
class Account
{
	private $con;
	private $error_array;
	public function __construct($con)
	{
		$this->con = $con;
		$this->error_array = array(); //same as []
	}
	public function register($un, $fn, $ln, $em, $em2, $pw, $pw2, $vkey)
	{
		$this->validate_username($un);
		$this->validate_firstname($fn);
		$this->validate_lastname($ln);
		$this->validate_image();
		$this->validate_emails($em, $em2);
		$this->validate_passwords($pw, $pw2);
		if (empty($this->error_array) == true) {
			return $this->insert_user_details($un, $fn, $ln, $em, $pw, $vkey);
		} else {
			return false;
		}
	}
	private function insert_user_details($un, $fn, $ln, $em, $pw, $vkey)
	{
		$encrypt_pw = password_hash($pw, PASSWORD_DEFAULT); //one more is md5
		$image_name = $_FILES['image_file']['name'];
		$temp_name = $_FILES['image_file']['tmp_name'];
		$folder = 'images/' . $image_name; //for encryption we can use md5( 'images/' . $image_name);//can also use this password_hash('images/' . $image_name, PASSWORD_DEFAULT)
		move_uploaded_file($temp_name, $folder);

		$_SESSION['profile_pic'] = $folder;
		$date = date("Y-m-d h:i:s a");


		$result = mysqli_query($this->con, "insert into register values('', '$un', '$fn', '$ln', '$em', '$encrypt_pw', '$date', '$folder',$vkey,'')");
		return $result;
	}
	public function get_error($error)
	{
		if (!in_array($error, $this->error_array)) {
			$error = "";
		}
		return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
	}
	private function validate_image()
	{

		if ($_FILES['image_file']['type'] == 'image/jpg' || $_FILES['image_file']['type'] == 'image/jpeg' || $_FILES['image_file']['type'] == 'image/png') {
			//not working on != jpg/jpeg
			return;
		} else {

			array_push($this->error_array, Constants::$image_type);
			return;
		}
	}
	private function validate_username($un)
	{
		$s_un = substr($un, 0, 1);
		if (preg_match("/[^a-zA-Z]/", $s_un)) {
			array_push($this->error_array, "Username Start from Character");
			return;
		}
		if (strlen($un) > 25 || strlen($un) < 5) {
			array_push($this->error_array, Constants::$user_name_characters);
			return;
		}
	}
	private function validate_firstname($fn)
	{
		if (strlen($fn) > 25 || strlen($fn) < 2) {
			array_push($this->error_array, Constants::$first_name_characters);
			return;
		}
		if (preg_match("/[^A-Za-z]/", $fn)) {
			array_push($this->error_array, "First Name Can't Be Numeric");
			return;
		}
	}
	private function validate_lastname($ln)
	{
		if (strlen($ln) > 25 || strlen($ln) < 2) {
			array_push($this->error_array, Constants::$last_name_characters);
			return;
		}
		if (preg_match("/[^A-Za-z]/", $ln)) {
			array_push($this->error_array, "Last Name Can't Be Numeric");
			return;
		}
	}
	private function validate_emails($em, $em2)
	{
		if (($em != $em2)) {
			array_push($this->error_array, Constants::$email_donot_match);
			return;
		}

		if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
			array_push($this->error_array, Constants::$email_invalid);
			return;
		}
		$check_email = mysqli_query($this->con, "select email from register where email='$em'");
		if (mysqli_num_rows($check_email) != 0) {
			array_push($this->error_array, Constants::$email_exists);
			return;
		}
	}
	private function validate_passwords($pw, $pw2)
	{
		if ($pw != $pw2) {
			array_push($this->error_array, Constants::$password_donot_match);
			return;
		}
		if (strlen($pw) > 25 || strlen($pw) < 5) {
			array_push($this->error_array, Constants::$password_characters);
			return;
		}
		if (preg_match("/[^A-Za-z0-9]/", $pw)) {
			array_push($this->error_array, Constants::$password_alpha_numeric);
			return;
		}
	}
}
