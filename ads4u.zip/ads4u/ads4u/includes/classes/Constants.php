<?php
class Constants
{
        public static $user_name_characters = "your username must be between 5 and 25 characters";
        public static $first_name_characters = "your first name must be between 2 and 25 characters";
        public static $last_name_characters = "your last name must be between 2 and 25 characters";
        public static $email_donot_match = "Your email is not matching";
        public static $email_invalid = "Your email is invalid";
        public static $password_donot_match = "your password is not matching";
        public static $password_characters = "your password must contain between 5 and 25 characters";
        public static $password_alpha_numeric = "Your password must contain numbers and letters";

        public static $email_exists = "Email already exists";
        public static $image_type = "Image type should be JPG/JPEG/PNG";
}
