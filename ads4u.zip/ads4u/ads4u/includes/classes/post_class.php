<?php
class post_class
{
        private $con;
        private $error_array;
        public function __construct($con)
        {
                $this->con = $con;
                $this->error_array = array();
        }
        public function postattr($cat, $subcat, $con, $title, $des, $pr, $country, $state, $city, $cell_number)
        {
                /*
                $this->validate_category($cat);
                $this->validate_sub_category($cat, $subcat);
                */


                $this->validate_ad_title($title);

                $this->validate_description($des);

                $this->validate_state($state);

                $this->validate_city($city);

                $this->validate_cellnumber($cell_number);
                $this->validate_inpfile1();

                $this->validate_inpfile2();

                $this->validate_inpfile3();

                $this->validate_inpfile4();
                $this->validate_inpfile5();
                $this->validate_inpfile6();

                if (empty($this->error_array)) {
                        return $this->insert_data_db($cat, $subcat, $con, $title, $des, $pr, $country, $state, $city, $cell_number);
                } else {
                        return false;
                }
        }
        private function insert_data_db($cat, $subcat, $con, $title, $des, $pr, $country, $state, $city, $cell_number)
        {
                $email = $_SESSION['email'];

                $query = mysqli_query($this->con, "select id from register where email='$email' ");

                $result = mysqli_fetch_array($query);
                $rid = $result['id'];
                $query = mysqli_query($this->con, "select registerid from product where registerid='$rid'");
                //check for limit of ads
                if (mysqli_num_rows($query) > 15) {
                        echo "<script>alert('You cannot post more than 15 ads,if you want to post Ads then first pay for this!')</script>";
                } else {
                        // categoryid queries
                        $cat_query = mysqli_query($this->con, "select catid from category where category='$cat'");
                        if (mysqli_num_rows($cat_query) == 0) {

                                $i_cat_query = mysqli_query($this->con, "insert into category values('','$cat')");
                        }

                        $cat_query = mysqli_query($this->con, "select catid from category where category='$cat'");
                        $cat_result = mysqli_fetch_array($cat_query);
                        $cat_id = $cat_result['catid'];
                        //  subcategory queries
                        $subcat_query = mysqli_query($this->con, "select subcatid from subcategory where subcategory='$subcat'");
                        if (mysqli_num_rows($subcat_query) == 0) {

                                $i_subcat_query = mysqli_query($this->con, "insert into subcategory values('','$subcat') ");
                        }

                        $subcat_query = mysqli_query($this->con, "select subcatid from subcategory where subcategory='$subcat'");
                        $subcat_result = mysqli_fetch_array($subcat_query);
                        $subcat_id = $subcat_result['subcatid'];
                        // country queries
                        $country_query = mysqli_query($this->con, "select cid from country where cname='$country'");
                        if (mysqli_num_rows($country_query) == 0) {

                                $i_country = mysqli_query($this->con, "insert into country values('','$country')");
                        }
                        $country_query = mysqli_query($this->con, "select cid from country where cname='$country'");
                        $country_result = mysqli_fetch_array($country_query);
                        $country_id = $country_result['cid'];
                        // state queries
                        $state_query = mysqli_query($this->con, "select sid from state where sname='$state' ");
                        if (mysqli_num_rows($state_query) == 0) {

                                $i_state = mysqli_query($this->con, "insert into state values ('','$state')");
                        }
                        $state_query = mysqli_query($this->con, "select sid from state where sname='$state' ");
                        $state_result = mysqli_fetch_array($state_query);
                        $state_id = $state_result['sid'];
                        // city queries
                        $city_query = mysqli_query($this->con, "select cityid from city where cityname='$city'");
                        if (mysqli_num_rows($city_query) == 0) {

                                $i_city = mysqli_query($this->con, "insert into city values ('','$city')");
                        }
                        $city_query = mysqli_query($this->con, "select cityid from city where cityname='$city'");
                        $city_result = mysqli_fetch_array($city_query);
                        $city_id = $city_result['cityid'];

                        /*

                        $cat_query = mysqli_query($this->con, "select category from category where category='$cat'");

                        if (mysqli_num_rows($cat_query) < 1) {


                                $query = mysqli_query($this->con, "insert into category values('','$cat')");
                        }
                        $catid = mysqli_query($this->con, "select catid from category where category='$cat'");
                        $result = mysqli_fetch_array($catid);
                        $catid = $result['catid'];
                        $sub_cat_query = mysqli_query($this->con, "select catid,subcategory from subcategory where catid='$catid' and subcategory='$subcat'");
                        if (mysqli_num_rows($sub_cat_query) == 0) {
                                $query = mysqli_query($this->con, "insert into subcategory values('','$catid','$subcat')");
                        }
                        $email = $_SESSION['email'];
                        $query = mysqli_query($this->con, "select id from register where email='$email '");
                        $result = mysqli_fetch_array($query);
                        $rid = $_SESSION['rid'] = $result['id'];
                        */

                        //sub_category_id
                        /*
                        $query = mysqli_query($this->con, "select subcatid from subcategory where catid='$catid' and subcategory='$subcat'");
                        $result = mysqli_fetch_array($query);
                        $sub_cat_id = $result['subcatid'];
                        */
                        //user
                        // $query = mysqli_query($this->con, "SELECT id from register where email='$email'");
                        // $result = mysqli_fetch_array($query);
                        // $id = $result['id'];
                        //if same user user has different city || state || city then insert it
                        /*
                        $query = mysqli_query($this->con, "select registerid from user where registerid='$rid'");
                        if (mysqli_num_rows($query) > 0) {
                                $query = mysqli_query($this->con, "select * from user where registerid='$rid '");
                                $result = mysqli_fetch_array($query);
                                $u_country = $result['ucountry'];
                                $u_state = $result['ustate'];
                                $u_city = $result['ucity'];
                                if ($u_country != $country || $u_state != $state || $u_city != $city) {

                                        $query = mysqli_query($this->con, "insert into user values('','$rid','$country','$state','$city','$cell_number')");
                                        $query = mysqli_query($this->con, "select userid from user where registerid='$rid' and ucountry='$country' and ustate='$state' and ucity='$city'");
                                        $result = mysqli_fetch_array($query);
                                        $uid = $result['userid'];
                                } else {
                                        $query = mysqli_query($this->con, "select userid from user where registerid='$rid' and ucountry='$country' and ustate='$state' and ucity='$city'");
                                        $result = mysqli_fetch_array($query);
                                        $uid = $result['userid'];
                                }
                        } else {

                                $query = mysqli_query($this->con, "insert into user values('','$rid','$country','$state','$city','$cell_number')");
                                $query = mysqli_query($this->con, "select userid from user where registerid='$rid' and ucountry='$country' and ustate='$state' and ucity='$city'");
                                $result = mysqli_fetch_array($query);
                                $uid = $result['userid'];
                        }
                        */
                        //$query = mysqli_query($this->con, "insert into user values('','$rid','$country','$state','$city','$cell_number')");
                        //____

                        $f1 = $_FILES['inpFile1']['name'];
                        $f1 = explode(".", $f1);
                        $f1[0] = uniqid();
                        $f1 = $f1[0] . "." . $f1[1];


                        $temp_name = $_FILES['inpFile1']['tmp_name'];
                        move_uploaded_file($temp_name, 'images/' . $f1);
                        //____
                        $f2 = $_FILES['inpFile2']['name'];
                        $f2 = explode(".", $f2);
                        $f2[0] = uniqid();
                        $f2 = $f2[0] . "." . $f2[1];
                        $temp_name = $_FILES['inpFile2']['tmp_name'];
                        move_uploaded_file($temp_name, 'images/' . $f2);
                        //____
                        $f3 = $_FILES['inpFile3']['name'];
                        $f3 = explode(".", $f3);
                        $f3[0] = uniqid();
                        $f3 = $f3[0] . "." . $f3[1];
                        $temp_name = $_FILES['inpFile3']['tmp_name'];
                        move_uploaded_file($temp_name, 'images/' . $f3);
                        //____
                        $f4 = $_FILES['inpFile4']['name'];
                        $f4 = explode(".", $f4);
                        $f4[0] = uniqid();
                        $f4 = $f4[0] . "." . $f4[1];
                        $temp_name = $_FILES['inpFile4']['tmp_name'];
                        move_uploaded_file($temp_name, 'images/' . $f4);
                        //____
                        $f5 = $_FILES['inpFile1']['name'];
                        $f5 = explode(".", $f1);
                        $f5[0] = uniqid();
                        $f5 = $f5[0] . "." . $f5[1];
                        $temp_name = $_FILES['inpFile5']['tmp_name'];
                        move_uploaded_file($temp_name, 'images/' . $f5);
                        //____
                        $f6 = $_FILES['inpFile1']['name'];
                        $f6 = explode(".", $f6);
                        $f6[0] = uniqid();
                        $f6 = $f6[0] . "." . $f6[1];
                        $temp_name = $_FILES['inpFile6']['tmp_name'];
                        move_uploaded_file($temp_name, 'images/' . $f6);
                        $query = mysqli_query($this->con, "insert into product values('',$rid,$cat_id,$subcat_id,$country_id,$state_id,$city_id,'$cell_number','$con','$title','$des','$pr','$f1','$f2','$f3','$f4','$f5','$f6','')");
                        //        check karna han

                        //die($cell_number);

                        //ye smjhna han
                        //return true
                        return $query;



                        /*
                $this->validate_category($cat);
                $this->validate_sub_category($cat, $subcat);
                */
                }
        }
        /*

        private function validate_category($category)
        {
                $query = mysqli_query($this->con, "select category from category where category='$category'");
                if (mysqli_num_rows($query) > 0) {
                        return;
                } else {
                        $query = mysqli_query($this->con, "insert into category values('','$category')");
                        return;
                }
        }
        private function validate_sub_category($category, $subcat)
        {

                $catid = mysqli_query($this->con, "select catid from category where category='$category'");
                $result = mysqli_fetch_array($catid);
                $catid1 = $result['catid'];

                // echo "<script>console.log('Debug Objects: " . $catid .  "' );</script>";

                $query = mysqli_query($this->con, "select catid,subcategory from subcategory where catid='$catid1' and subcategory='$subcat'");

                if (mysqli_num_rows($query) > 0) {
                        return;
                } else {
                        $query = mysqli_query($this->con, "insert into subcategory values('','$catid1','$subcat')");
                        return;
                }
        }
        */


        private function validate_ad_title($title)
        {
                if (strlen($title) > 20 || strlen($title) < 3) {
                        array_push($this->error_array, "Your Ad-Title must contain between 3 and 20 characters");
                        return;
                }
        }
        private function validate_description($description)
        {
                if (strlen($description) > 2000 || strlen($description) < 5) {
                        array_push($this->error_array, "Your Ad-description must contain between 10 ad 2000 characters");
                        return;
                }
        }
        private function validate_state($state)
        {
                if (strlen($state) < 5) {
                        array_push($this->error_array, "State length must be greater than or equal to 5 charachters");
                        return;
                }
                if (preg_match("/[^a-zA-Z]/", $state)) {
                        array_push($this->error_array, "Your state must contain only Alphabets");
                }
        }
        private function validate_city($city)
        {
                if (strlen($city) < 3) {
                        array_push($this->error_array, "City length must be grater than or equal to 3 characters");
                        return;
                }
                if (preg_match("/[^a-zA-Z]/", $city)) {
                        array_push($this->error_array, "Your city must contain only Alphabets");
                }
        }
        private function validate_inpfile1()
        {

                $name = $_FILES['inpFile1']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($name == "jpg" || $name == "jpeg" || $name == "png") {

                        return;
                } else {
                        array_push($this->error_array, "1st Image type should be jpg,jpeg or png");
                }
        }
        private function validate_inpfile2()
        {

                $name = $_FILES['inpFile2']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($name == "jpg" || $name == "jpeg" || $name == "png") {

                        return;
                } else {
                        array_push($this->error_array, "2nd Image type should be jpg,jpeg or png");
                }
        }
        private function validate_inpfile3()
        {

                $name = $_FILES['inpFile3']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($name == "jpg" || $name == "jpeg" || $name == "png") {

                        return;
                } else {
                        array_push($this->error_array, "3rd Image type should be jpg,jpeg or png");
                }
        }
        private function validate_inpfile4()
        {
                $name = $_FILES['inpFile4']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($name == "jpg" || $name == "jpeg" || $name == "png") {

                        return;
                } else {
                        array_push($this->error_array, "4th Image type should be jpg,jpeg or png");
                }
        }
        private function validate_inpfile5()
        {
                $name = $_FILES['inpFile5']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                /*
                if ($name != "jpg" || $name != "jpeg" || $name != "png") {
                        array_push($this->error_array, "5Image type should be jpg,jpeg or png");
                        return;
                }
                not workig this->dont know why..
                */


                if ($name == "jpg" || $name == "jpeg" || $name == "png") {

                        return;
                } else {
                        array_push($this->error_array, "5th Image type should be jpg,jpeg or png");
                }
        }
        private function validate_inpfile6()
        {

                $name = $_FILES['inpFile6']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($name == "jpg" || $name == "jpeg" || $name == "png") {

                        return;
                } else {
                        array_push($this->error_array, "6th Image type should be jpg,jpeg or png");
                }
        }


        private function validate_cellnumber($cell_number)
        {

                $cell_number1 = substr($cell_number, 1);

                if ($cell_number[0] != '+') {
                        array_push($this->error_array, "Your cell number must be like this +[countrycode][cell-number]");
                        return;
                }

                if (preg_match("/[^0-9]/", $cell_number1)) {
                        array_push($this->error_array, "Your cell number must be like this +[countrycode][cell-number]");

                        return;
                }
        }


        public function check_error($error)
        {
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<br><span class='error_message' style='color:red; font-size: 13px; font-weight:bold; ' >$error</span>";
        }
}
