<?php
class contact_class
{
        private $error_array;
        public function __construct()
        {
                $this->error_array = array();
        }
        public function validate_contact($fname, $lname, $email, $subject, $message)
        {
                $this->validate_fname($fname);
                $this->validate_lname($lname);
                $this->validate_email($email);
                $this->validate_subject($subject);
                $this->validate_message($message);
                if (empty($this->error_array)) {
                        return true;
                } else {
                        return false;
                }
        }
        public function check_error($error)
        {
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
        }
        private function validate_fname($fname)
        {
                if (strlen($fname) < 2 || strlen($fname) > 10) {
                        array_push($this->error_array, "length between 2-10 characters");
                        return;
                }
                if (preg_match("/[^a-zA-Z]/", $fname)) {
                        array_push($this->error_array, "contain only alphabets");
                        return;
                }
        }
        private function validate_lname($lname)
        {
                if (strlen($lname) < 2 || strlen($lname) > 10) {
                        array_push($this->error_array, "length between 2 to 10 characters");
                        return;
                }
                if (preg_match("/[^a-zA-Z]/", $lname)) {
                        array_push($this->error_array, "it contain only alphabets");
                        return;
                }
        }
        private function validate_email($email)
        {
                // $email = filter_var($email, FILTER_SANITIZE_EMAIL); remove the illegal characters
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        array_push($this->error_array, "Your email is not valid");
                        return;
                }
        }
        private function validate_subject($subject)
        {
                if (strlen($subject) < 5 || strlen($subject) > 40) {
                        array_push($this->error_array, "length must be betweeb 5-40 characters");
                        return;
                }
        }
        private function validate_message($message)
        {
                if (strlen($message) < 5 || strlen($message) > 500) {
                        array_push($this->error_array, "message length should be between 5-500 characters");
                        return;
                }
        }
}
