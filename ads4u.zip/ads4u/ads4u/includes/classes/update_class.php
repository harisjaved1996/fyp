<?php
class update_class
{
        private $con;
        private $error_array;
        public function __construct($con)
        {
                $this->con = $con;
                $this->error_array = array();
        }
        public function postattr($cat, $subcat, $con, $title, $des, $pr, $country, $state, $city, $cell_number)
        {
                /*
                $this->validate_category($cat);
                $this->validate_sub_category($cat, $subcat);
                */


                $this->validate_ad_title($title);

                $this->validate_description($des);

                $this->validate_state($state);

                $this->validate_city($city);

                $this->validate_cellnumber($cell_number);
                $this->validate_inpfile1();

                $this->validate_inpfile2();

                $this->validate_inpfile3();

                $this->validate_inpfile4();
                $this->validate_inpfile5();
                $this->validate_inpfile6();

                if (empty($this->error_array)) {

                        return $this->insert_data_db($cat, $subcat, $con, $title, $des, $pr, $country, $state, $city, $cell_number);
                } else {

                        return false;
                }
        }
        private function insert_data_db($cat, $subcat, $con, $title, $des, $pr, $country, $state, $city, $cell_number)
        {
                //print_r($this->error_array);
                // 
                $f1 = $_FILES['inpFile1']['name'];
                $f1 = explode(".", $f1);
                $f1[0] = uniqid();
                $f1 = $f1[0] . "." . $f1[1];


                $temp_name = $_FILES['inpFile1']['tmp_name'];
                move_uploaded_file($temp_name, 'images/' . $f1);
                //____
                $f2 = $_FILES['inpFile2']['name'];
                $f2 = explode(".", $f2);
                $f2[0] = uniqid();
                $f2 = $f2[0] . "." . $f2[1];
                $temp_name = $_FILES['inpFile2']['tmp_name'];
                move_uploaded_file($temp_name, 'images/' . $f2);
                //____
                $f3 = $_FILES['inpFile3']['name'];
                $f3 = explode(".", $f3);
                $f3[0] = uniqid();
                $f3 = $f3[0] . "." . $f3[1];
                $temp_name = $_FILES['inpFile3']['tmp_name'];
                move_uploaded_file($temp_name, 'images/' . $f3);
                //____
                $f4 = $_FILES['inpFile4']['name'];
                $f4 = explode(".", $f4);
                $f4[0] = uniqid();
                $f4 = $f4[0] . "." . $f4[1];
                $temp_name = $_FILES['inpFile4']['tmp_name'];
                move_uploaded_file($temp_name, 'images/' . $f4);
                //____
                $f5 = $_FILES['inpFile1']['name'];
                $f5 = explode(".", $f1);
                $f5[0] = uniqid();
                $f5 = $f5[0] . "." . $f5[1];
                $temp_name = $_FILES['inpFile5']['tmp_name'];
                move_uploaded_file($temp_name, 'images/' . $f5);
                //____
                $f6 = $_FILES['inpFile1']['name'];
                $f6 = explode(".", $f6);
                $f6[0] = uniqid();
                $f6 = $f6[0] . "." . $f6[1];
                $temp_name = $_FILES['inpFile6']['tmp_name'];
                move_uploaded_file($temp_name, 'images/' . $f6);
                // product primary key
                $productid = $_SESSION['productid11'];
                // updating category
                $query = mysqli_query($this->con, "select catid from category where category='$cat' ");
                if (mysqli_num_rows($query) > 0) {
                        $result1 = mysqli_fetch_array($query);
                        $update_catid = $result1['catid'];
                        // $query = mysqli_query($this->con, "DELETE FROM CATEGORY WHERE CATID='$catid'");

                } else {
                        $query = mysqli_query($this->con, "insert into category values('','$cat')");
                        $query = mysqli_query($this->con, "select catid from category where category='$cat' ");
                        $result1 = mysqli_fetch_array($query);
                        $update_catid = $result1['catid'];
                }


                //updating subcategory
                $query = mysqli_query($this->con, "select subcatid from subcategory where subcategory='$subcat' ");
                if (mysqli_num_rows($query) > 0) {
                        $result1 = mysqli_fetch_array($query);
                        $update_subcatid = $result1['subcatid'];


                        // $query = mysqli_query($this->con, "DELETE FROM SUBCATEGORY WHERE CATID=$catid and subcatid=$subcatid");
                } else {
                        $query = mysqli_query($this->con, "insert into subcategory values ('','$subcat')");
                        $query = mysqli_query($this->con, "select subcatid from subcategory where subcategory='$subcat' ");
                        $result1 = mysqli_fetch_array($query);
                        $update_subcatid = $result1['subcatid'];
                }
                // country updating queries
                $query = mysqli_query($this->con, "select cid from country where cname='$country'");
                if (mysqli_num_rows($query) > 0) {
                        $result1 = mysqli_fetch_array($query);
                        $update_cid = $result1['cid'];
                } else {
                        $query = mysqli_query($this->con, "insert into country values ('','$country')");
                        $query = mysqli_query($this->con, "select cid from country where cname='$country'");
                        $result1 = mysqli_fetch_array($query);
                        $update_cid = $result1['cid'];
                }
                // updating state queries
                $query = mysqli_query($this->con, "select sid from state where sname='$state'");
                if (mysqli_num_rows($query) > 0) {
                        $result1 = mysqli_fetch_array($query);
                        $update_sid = $result1['sid'];
                } else {
                        $query = mysqli_query($this->con, "insert into state values ('','$state')");
                        $query = mysqli_query($this->con, "select sid from state where sname='$state'");
                        $result1 = mysqli_fetch_array($query);
                        $update_sid = $result1['sid'];
                }
                // updateing city queries
                $query = mysqli_query($this->con, "select cityid from city where cityname='$city'");
                if (mysqli_num_rows($query) > 0) {
                        $result1 = mysqli_fetch_array($query);
                        $update_cityid = $result1['cityid'];
                } else {
                        $query = mysqli_query($this->con, "insert into city values ('','$city')");
                        $query = mysqli_query($this->con, "select cityid from city where cityname='$city'");
                        $result1 = mysqli_fetch_array($query);
                        $update_cityid = $result1['cityid'];
                }

                // updating product
                $query = mysqli_query($this->con, "update product set catid=$update_catid,subcatid=$update_subcatid,cid=$update_cid,sid=$update_sid,cityid=$update_cityid,cellnumber='$cell_number',con='$con',ptitle='$title',pdescription='$des',pprice='$pr',pimage1='$f1',pimage2='$f1',pimage3='$f3',pimage4='$f4',pimage5='$f5',pimage5='$f6',verified=0 where pid='$productid'");
                // $userid=$result['uid'];
                // $query = mysqli_query($this->con, "update user set ucountry='$country',ustate='$state',ucity='$city',ucellnumber='$cell_number' where userid='$userid'");
                // $query = mysqli_query($this->con, "update category set category='$cat' where catid='$catid'");
                // $query = mysqli_query($this->con, "update subcategory set subcategory='$subcat' where subcatid='$subcatid'");
                // // // $catid=$result['catid'];
                // // $query=mysqli_query()

                //die($cell_number);

                //ye smjhna han
                //return true

                return $query;



                /*
                $this->validate_category($cat);
                $this->validate_sub_category($cat, $subcat);
                */
        }
        /*

        private function validate_category($category)
        {
                $query = mysqli_query($this->con, "select category from category where category='$category'");
                if (mysqli_num_rows($query) > 0) {
                        return;
                } else {
                        $query = mysqli_query($this->con, "insert into category values('','$category')");
                        return;
                }
        }
        private function validate_sub_category($category, $subcat)
        {

                $catid = mysqli_query($this->con, "select catid from category where category='$category'");
                $result = mysqli_fetch_array($catid);
                $catid1 = $result['catid'];

                // echo "<script>console.log('Debug Objects: " . $catid .  "' );</script>";

                $query = mysqli_query($this->con, "select catid,subcategory from subcategory where catid='$catid1' and subcategory='$subcat'");

                if (mysqli_num_rows($query) > 0) {
                        return;
                } else {
                        $query = mysqli_query($this->con, "insert into subcategory values('','$catid1','$subcat')");
                        return;
                }
        }
        */


        private function validate_ad_title($title)
        {
                if (strlen($title) > 20 || strlen($title) < 3) {
                        array_push($this->error_array, "Your Ad-Title must contain between 3 and 20 characters");
                        return;
                }
        }
        private function validate_description($description)
        {
                if (strlen($description) > 2000 || strlen($description) < 5) {
                        array_push($this->error_array, "Your Ad-description must contain between 10 ad 2000 characters");
                        return;
                }
        }
        private function validate_state($state)
        {
                if (strlen($state) < 5) {
                        array_push($this->error_array, "State length must be greater than or equal to 5 charachters");
                        return;
                }
                if (preg_match("/[^a-zA-Z]/", $state)) {
                        array_push($this->error_array, "Your state must contain only Alphabets");
                }
        }
        private function validate_city($city)
        {
                if (strlen($city) < 3) {
                        array_push($this->error_array, "City length must be grater than or equal to 3 characters");
                        return;
                }
                if (preg_match("/[^a-zA-Z]/", $city)) {
                        array_push($this->error_array, "Your city must contain only Alphabets");
                }
        }
        private function validate_inpfile1()
        {
                $image_name = $_FILES['inpFile1']['name'];
                $name = $_FILES['inpFile1']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));

                echo "<br>";
                if ($image_name == "") {
                        array_push($this->error_array, "Please Select your input file 1");
                        return;
                }
                if ($name != "jpg" && $name != "jpeg" && $name != "png") {

                        array_push($this->error_array, "1st Image type should be jpg,jpeg or png");
                        return;
                }
        }
        private function validate_inpfile2()
        {
                $image_name = $_FILES['inpFile2']['name'];
                $name = $_FILES['inpFile2']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($image_name == "") {
                        array_push($this->error_array, "Please Select your input file 2");
                        return;
                }
                if ($name != "jpg" && $name != "jpeg" && $name != "png") {
                        array_push($this->error_array, "2nd Image type should be jpg,jpeg or png");
                        return;
                }
        }
        private function validate_inpfile3()
        {
                $image_name = $_FILES['inpFile3']['name'];
                $name = $_FILES['inpFile3']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($image_name == "") {
                        array_push($this->error_array, "Please Select your input file 3");
                        return;
                }
                if ($name != "jpg" && $name != "jpeg" && $name != "png") {
                        array_push($this->error_array, "3rd Image type should be jpg,jpeg or png");
                        return;
                }
        }
        private function validate_inpfile4()
        {
                $image_name = $_FILES['inpFile4']['name'];
                $name = $_FILES['inpFile4']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($image_name == "") {
                        array_push($this->error_array, "Please Select your input file 4");
                        return;
                }
                if ($name != "jpg" && $name != "jpeg" && $name != "png") {
                        array_push($this->error_array, "4th Image type should be jpg,jpeg or png");
                        return;
                }
        }
        private function validate_inpfile5()
        {
                $image_name = $_FILES['inpFile5']['name'];
                $name = $_FILES['inpFile5']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                /*
                if ($name != "jpg" || $name != "jpeg" || $name != "png") {
                        array_push($this->error_array, "5Image type should be jpg,jpeg or png");
                        return;
                }
                not workig this->dont know why..
                */


                if ($image_name == "") {
                        array_push($this->error_array, "Please Select your input file 5");
                        return;
                }
                if ($name != "jpg" && $name != "jpeg" && $name != "png") {
                        array_push($this->error_array, "5th Image type should be jpg,jpeg or png");
                        return;
                }
        }
        private function validate_inpfile6()
        {
                $image_name = $_FILES['inpFile6']['name'];
                $name = $_FILES['inpFile6']['type'];
                $name = explode("/", $name);
                $name = strtolower(end($name));
                if ($image_name == "") {
                        array_push($this->error_array, "Please Select your input file 6");
                        return;
                }
                if ($name != "jpg" && $name != "jpeg" && $name != "png") {
                        array_push($this->error_array, "6th Image type should be jpg,jpeg or png");
                        return;
                }
        }


        private function validate_cellnumber($cell_number)
        {

                $cell_number1 = substr($cell_number, 1);

                if ($cell_number[0] != '+') {
                        array_push($this->error_array, "Your cell number must be like this +[countrycode][cell-number]");
                        return;
                }

                if (preg_match("/[^0-9]/", $cell_number1)) {
                        array_push($this->error_array, "Your cell number must be like this +[countrycode][cell-number]");

                        return;
                }
        }


        public function check_error($error)
        {
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<br><span class='error_message' style='color:red; font-size: 13px; font-weight:bold; ' >$error</span>";
        }
}
