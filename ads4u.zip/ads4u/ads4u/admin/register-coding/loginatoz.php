<?php
class admin_login_class
{
        private $con;
        private $error_array;
        public function __construct($con)
        {
                $this->con = $con;
                $this->error_array = array();
        }
        public function get_error($error)
        {
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
        }

        public function main_fun($email, $pass)
        {
                $query = mysqli_query($this->con, "SELECT * FROM ADMIN WHERE email='$email'");

                if (mysqli_num_rows($query) > 0) {

                        $result = mysqli_fetch_array($query);
                        $password = $result['password'];

                        if (password_verify($pass, $password)) {




                                $verified = $result['verified'];
                                if ($verified == 1) {

                                        $_SESSION['firstname'] = $result['firstname'];
                                        $_SESSION['lastname'] = $result['lastname'];
                                        return true;
                                } else {
                                        $_SESSION['email_admin'] = $result['email'];
                                        $_SESSION['vkey_admin'] = $result['vkey'];
                                        $_SESSION['email_admin2'] = 'admin';
                                        header("location:admin_verification_msg.php");
                                }
                        } else {


                                array_push($this->error_array, "Invalid Email or Password");
                                return false;
                        }
                } else {

                        array_push($this->error_array, "Invalid Email or Password");
                        return false;
                }
        }
}
$admin_login_class = new admin_login_class($con);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $email = setstring($_POST['myemail']);
        $pass = $_POST['mypassword'];

        $is_successfull = $admin_login_class->main_fun($email, $pass);

        if ($is_successfull == true) {


                header("location:tables.php");
        }
}
function setstring($s1)
{
        $s1 = strip_tags($s1);
        $s1 = str_replace(" ", "", $s1);
        $s1 = strtolower($s1);
        return $s1;
}
