<?php
class admin_class
{
        private $con;
        private $error_array;
        public function __construct($con)
        {
                $this->con = $con;
                $this->error_array = array();
        }
        public function main_fun($fn, $ln, $em, $pas, $cpas)
        {
                $this->validate_fn($fn);
                $this->validate_ln($ln);
                $this->validate_em($em);
                $this->validate_pass($pas, $cpas);
                if (empty($this->error_array)) {
                        return $this->admin_details($fn, $ln, $em, $pas, $cpas);
                } else {
                        return false;
                }
        }
        private function admin_details($fn, $ln, $em, $pas)
        {
                $vkey = rand(100000, 999999);
                $_SESSION['vkey_admin'] = $vkey;
                $pas = password_hash($pas,  PASSWORD_DEFAULT);

                $query = mysqli_query($this->con, "insert into admin values('','$fn','$ln','$em','$pas','$vkey','')");
                return $query;
        }
        public function check_error($error)
        {
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
        }
        private function validate_fn($fn)
        {
                if (strlen($fn) > 25 || strlen($fn) < 3) {
                        array_push($this->error_array, "First name must be between 3 and 25 characters");
                        return;
                }
        }
        private function validate_ln($ln)
        {
                if (strlen($ln) > 25 || strlen($ln) < 3) {
                        array_push($this->error_array, "last name must be between 3 and 25 characters");
                        return;
                }
        }
        private function validate_em($em)
        {
                if (!filter_var($em)) {
                        array_push($this->error_array, "Invalid Email Address");
                        return;
                }
                $query = mysqli_query($this->con, "SELECT * FROM ADMIN WHERE email='$em'");
                if (mysqli_num_rows($query) > 0) {
                        array_push($this->error_array, "Email Already exist");
                        return;
                }
        }
        private function validate_pass($pas, $cpas)
        {
                if ($pas != $cpas) {
                        array_push($this->error_array, "Your password is not matching");
                        return;
                }
                if (strlen($pas) > 20 || strlen($pas) < 5) {
                        array_push($this->error_array, "Your password length must be betwwen 5 and 25 characters");
                        return;
                }
                if (preg_match("/[^a-zA-z0-9]/", $pas)) {
                        array_push($this->error_array, "Password must be alpha numeric");
                        return;
                }
        }
}
$admin_register = new admin_class($con);
function set_string($s1)
{
        $s1 = strip_tags($s1);
        $s1 = str_replace(" ", "", $s1);
        $s1 = strtolower($s1);
        return $s1;
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $fname = set_string($_POST['firstname']);
        $lname = set_string($_POST['lastname']);
        $email = set_string($_POST['email']);
        $password = set_string($_POST['password']);
        $cpassword = set_string($_POST['cpassword']);
        $is_sucessfull = $admin_register->main_fun($fname, $lname, $email, $password, $cpassword);
        if ($is_sucessfull) {
                //after successfull registration
                $_SESSION['email_admin'] = $email;
                $_SESSION['email_admin2'] = 'admin';



                header("location:admin_verification_msg.php");
        }
}
