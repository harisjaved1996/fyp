<?php
include("../includes/config.php");
$productid = $_POST['product_id'];
$query = mysqli_query($con, "update product set verified=-1 where pid='$productid' ");
if ($query == 1) {
        echo 1;
}
