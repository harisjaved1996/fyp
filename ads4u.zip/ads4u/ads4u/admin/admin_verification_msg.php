<?php
include("../includes/config.php");

if ((isset($_SESSION['email_admin'])) && (isset($_SESSION['email_admin2']))) {



        function sendmail()
        {

                //owner,s email id
                $to = 'ads4u1122@gmail.com';

                $sub = "Verification Code to admin From ADS4U";
                $msg = "Dear Your Verification Code is:" . $_SESSION['vkey_admin'];
                if (mail($to, $sub, $msg)) {
                        return;
                } else {
                        echo "your Internet Connection is bad";
                }
        }
        sendmail();
        unset($_SESSION['email_admin2']);
} elseif (!(isset($_SESSION['email_admin'])) && !(isset($_SESSION['email_admin2']))) {
        header("location:index.php");
}


class verification_admin
{
        private $con;
        private $error_array;
        public function __construct($con)
        {
                $this->con = $con;
                $this->error_array = array();
        }
        public function check_verification($vinput, $email)
        {

                $this->get_vkey($vinput, $email);

                if (empty($this->error_array)) {

                        $query = mysqli_query($this->con, "UPDATE ADMIN SET verified=1 WHERE email='$email'");

                        if ($query) {

                                return true;
                        } else {
                                return false;
                        }
                }
        }
        public function verification_error($error)
        {
                if (!in_array($error, $this->error_array)) {
                        $error = "";
                }
                return "<span class='error_message' style='color: #ff8787;font-weight: bold; font-size: 20px;letter-spacing: 0.7px;  ' >$error</span>";
        }
        private function get_vkey($vinput, $email)
        {

                $query = mysqli_query($this->con, "SELECT * from admin where email='$email' ");
                $result = mysqli_fetch_array($query);
                $vkey = $result['vkey'];

                if ($vinput != $vkey) {
                        array_push($this->error_array, "You enter invalid verification code");
                        return;
                } else {
                        $em = $_SESSION['email_admin'];
                        $query = mysqli_query($this->con, "select * from admin where email='$em'");
                        $result = mysqli_fetch_array($query);
                        $_SESSION['firstname'] = $result['firstname'];
                        $_SESSION['lastname'] = $result['lastname'];
                        return true;
                }
        }
}
$verification = new verification_admin($con);
if ($_SERVER["REQUEST_METHOD"] == "POST") {


        $email = $_SESSION['email_admin'];
        $vinput = $_POST['input_number'];

        //$email = $_SESSION['email'];
        $result = $verification->check_verification($vinput, $email);
        if ($result == true) {


                header("location:tables.php");
        }
}
/*
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $verifica
        $error_array = array();
        function check_error($error)
        {
                global $error_array;
                if (!in_array($error, $error_array)) {
                        $error = "";
                }
                return "<span class='error_message' style='color:red; font-weight:bold; ' >$error</span>";
        }
        $vinput = $_POST['input_number'];
        $email = $_SESSION['email'];
        $query = mysqli_query($con, "SELECT * from register where email='$email' ");
        $result = mysqli_fetch_array($query);
        $vkey = $result['vkey'];
        $username = $result['username'];
        if ($vinput == $vkey) {
                $query = mysqli_query($con, "UPDATE REGISTER SET verified=1 WHERE email='$email'");
                $_SESSION['username'] = $username;
                header("location:congratulation_msg.php");
        } else {
                array_push($error_array, "You enter invalid verification code");
        }
}
*/

?>
<html>

<head>
        <title>
                ADmin
        </title>
        <link rel="stylesheet" href="../css/verification_msg.css" />
        <style>

        </style>
        <script src="../js/jquery.js"></script>
        <script>
                $(document).ready(function() {
                        $('#cancel_button').click(function() {
                                window.location.href = "session-destroy-admin.php";
                        });
                });
        </script>

</head>

<body>
        <div id="verfication_container">
                <center>

                        <img src="../images/gmail_verification_icon.png" alt="gamil_verification_image" id="gmail_verification_images" />
                        <div id="verification_msg">
                                <h1 id="verification_msg_h1">Verify your Account</h1>
                                <h3 id="verification_msg_h3">To make sure this account is yours,<span id="ads4u">Your verification key</span>
                                        has been sent to the owner of the website
                                </h3>
                                <form action="admin_verification_msg.php" method="POST" id="verification_msg_form">
                                        <input type="number" name="input_number" required id="verification_input" /><br>
                                        <?php echo $verification->verification_error("You enter invalid verification code"); ?>
                                        <div id="btns">
                                                <input type="submit" name="submit_verfication" id="submit_verifiaction" value="confirm" />
                                                <input type="button" id="cancel_button" value="cancel">
                                        </div>

                                </form>
                        </div>

                </center>
        </div>
</body>

</html>