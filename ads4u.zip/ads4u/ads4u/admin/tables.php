<?php
include("../includes/config.php");

if ((isset($_SESSION['firstname'])) && (isset($_SESSION['lastname']))) {
  // 
  $u_query = mysqli_query($con, "select * from register");
  $total_users = mysqli_num_rows($u_query);
  // 
  $p_query = mysqli_query($con, "select * from product");

  $total_ads = mysqli_num_rows($p_query);




  echo "<!DOCTYPE html>
<html lang='en'>

<head>

<style>
    #load-users{height: 32px;
    font-size: 19px;
    color: #291f1f;}
  img {
   height:200px;
   width:200px;
 }
 
div.db_data * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
      }
      div.db_data {
        padding: 0 0 2% 0;
        width: 100%;
      }
      div.db_grid {
        width: 80%;
        margin: 0px auto;

        display: grid;
        grid-gap: 1%;
        grid-template-columns: repeat(2, 1fr);
      }
      div.grid_item {
        background-color: gray;
        border-radius:10px;
        text-align: center;
        padding: 5% 0;
      }
      div.grid_item > h4 {
        font-size: 20px;
        font-weight: bold;
        color: white;
        padding: 1% 0;
      }
    
</style>
 

  <meta charset='utf-8'>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
  <meta name='description' content=''>
  <meta name='author' content=''>

  <title>SB Admin - Tables</title>

  <!-- Custom fonts for this template-->
  <link href='vendor/fontawesome-free/css/all.min.css' rel='stylesheet' type='text/css'>

  <!-- Page level plugin CSS-->
  <link href='vendor/datatables/dataTables.bootstrap4.css' rel='stylesheet'>

  <!-- Custom styles for this template-->
  <link href='css/sb-admin.css' rel='stylesheet'>

</head>

<body id='page-top'>

  <nav class='navbar navbar-expand navbar-dark bg-dark static-top'>
   <a class='navbar-brand mr-1' href='session-destroy-admin.php'>Log Out</a>

   

    
     

    <!-- Navbar Search -->
    
    <form class='d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0'>
      
    </form>

    <!-- Navbar -->
    
  </nav>
    <div id='wrapper'>

    <!-- Sidebar -->
    

    <div id='content-wrapper'>

      <div class='container-fluid'>

        <!-- Breadcrumbs-->
        

        <!-- DataTables Example -->
       <div class='db_data'>
      <div class='db_grid'>
        <div class='grid_item1 grid_item'>
          <h3>Total Users</h3>
          <h4>$total_users</h4>
        </div>
        <div class='grid_item2 grid_item'>
          <h3>Total Ads</h3>
          <h4>$total_ads</h4>
        </div>
       
      </div>
    </div>
        <div class='card mb-3'>
          <div style='text-align:center;' class='card-header'>
            <button id='load-users' class='fa fa-spinner' onclick='loadtable()'> Load Users</button>
          </div>
            
          
            <div id='table_data_div' class='table-responsive'>
              
            </div>
          
          
        </div>

       

      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      
    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class='scroll-to-top rounded' href='#page-top'>
    <i class='fas fa-angle-up'></i>
  </a>

  <!-- Logout Modal-->
  <div class='modal fade' id='logoutModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
    <div class='modal-dialog' role='document'>
      <div class='modal-content'>
        <div class='modal-header'>
          <h5 class='modal-title' id='exampleModalLabel'>Ready to Leave?</h5>
          <button class='close' type='button' data-dismiss='modal' aria-label='Close'>
            <span aria-hidden='true'>×</span>
          </button>
        </div>
        <div class='modal-body'>Select 'Logout' below if you are ready to end your current session.</div>
        <div class='modal-footer'>
          <button class='btn btn-secondary' type='button' data-dismiss='modal'>Cancel</button>
          <a class='btn btn-primary' href='index.php'>Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  
 
  <script src='vendor/jquery/jquery.min.js'></script>
  <script src='vendor/bootstrap/js/bootstrap.bundle.min.js'></script>

  <!-- Core plugin JavaScript-->
  <script src='vendor/jquery-easing/jquery.easing.min.js'></script>

  <!-- Page level plugin JavaScript-->
  <script src='vendor/datatables/jquery.dataTables.js'></script>
  <script src='vendor/datatables/dataTables.bootstrap4.js'></script>

  <!-- Custom scripts for all pages-->
  <script src='js/sb-admin.min.js'></script>

  <!-- Demo scripts for this page-->
  <script src='js/demo/datatables-demo.js'></script>

</body>

</html>";
  echo "<script='../js/jquery.js'></script>
      <script>
      $('document').ready(function(){
        $('#pages').hide();
      });
      </script>
      ";
  echo "<script>
  function loadtable(){
     $.ajax({
        url:'load_users.php',
        type:'post',
        success:function(data){
          $('#table_data_div').html(data);
        }
      });    
  }
  
  function image_verification(x){

    var data=x;
     $.ajax({
        url:'valid_image_verify.php',
        type:'post',
        data:{product_id:data},
        success:function(data){
          if(data==1){
            loadtable();
          }
          else{
            alert('Cant verify the image');
          }
          
        }
      });     
  }
  function image_illegal(x){
     var data=x;
     $.ajax({
        url:'image_dismiss.php',
        type:'post',
        data:{product_id:data},
        success:function(data){
          if(data==1){
            loadtable();
          }
          else{
            alert('Cant dismiss the product');
          }
          
        }
      });     
     
  }
  </script>";
} else {

  header("location:index.php");
}
