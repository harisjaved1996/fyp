<?php
// session_start();
// session_unset();
// session_destroy();
// header("location:index.php");
session_start();
unset($_SESSION['firstname']);
unset($_SESSION['lastname']);
header("location:index.php");
