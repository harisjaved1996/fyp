<?php
include("../includes/config.php");
include("register-coding/register_a2z.php");

function set_value($s)
{
  if (isset($_POST[$s])) {
    return $_POST[$s];
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>SB Admin - Register</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body class="bg-dark">

  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form method="POST" action="register.php">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" name="firstname" value="<?php echo set_value('firstname'); ?>" id="firstName" class="form-control" placeholder="First name" required="required" autofocus="autofocus">
                  <label for="firstName">First name</label>
                </div>
                <?php echo $admin_register->check_error('First name must be between 3 and 25 characters'); ?>
              </div>
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" name="lastname" value="<?php echo set_value('lastname'); ?>" id="lastName" class="form-control" placeholder="Last name" required="required">
                  <label for="lastName">Last name</label>
                </div>
                <?php echo $admin_register->check_error('last name must be between 3 and 25 characters'); ?>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="email" name="email" value="<?php echo set_value('email'); ?>" id="inputEmail" class="form-control" placeholder="Email address" required="required">
              <label for="inputEmail">Email address</label>
            </div>
            <?php echo $admin_register->check_error('Invalid Email Address'); ?>
            <?php echo $admin_register->check_error('Email Already exist'); ?>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required="required">
                  <label for="inputPassword">Password</label>
                </div>
                <?php echo $admin_register->check_error('Your password is not matching'); ?>
                <?php echo $admin_register->check_error('Your password length must be betwwen 5 and 25 characters'); ?>
                <?php echo $admin_register->check_error('Password must be alpha numeric'); ?>

              </div>
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="password" name="cpassword" id="confirmPassword" class="form-control" placeholder="Confirm password" required="required">
                  <label for="confirmPassword">Confirm password</label>
                </div>
              </div>
            </div>
          </div>
          <input class="btn btn-primary btn-block" id="submit" type="submit" value="Register" name="submit">

        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="index.php">Login Page</a>

        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>