<?php
include("../includes/config.php");
$query = mysqli_query($con, "select pid,username,cname,sname,cityname,pprice,pimage1,pimage2,pimage3,pimage4,pimage5,pimage6 from product inner JOIN register on product.registerid=register.id INNER JOIN country on product.cid=country.cid INNER join state on product.sid=state.sid INNER join city ON product.cityid=city.cityid and product.verified=0");
// $query = mysqli_query($con, "select pid,username,ucountry,ustate,ucity,pprice,pimage1,pimage2,pimage3,pimage4,pimage5,pimage6 from register inner join user on register.id=user.registerid inner join product on user.userid=product.uid and product.verified=0");
if (mysqli_num_rows($query) > 0) {
        $output = " <table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
                <thead>
                  <tr>
                    
                    <th>User Name</th>
                    <th>User Country</th>
                    <th>User State</th>
                    <th>User City</th>
                    
                    <th>User Product-price</th>
                    <th>User Product-image1</th>
                    <th>User Product-image2</th>
                    <th>User Product-image3</th>
                    <th>User Product-image4</th>
                    <th>User Product-image5</th>
                    <th>User Product-image6</th>
                    <th>Confirm Verification</th>
                    <th>Dismiss Product</th>
                  </tr>
                </thead>";

        while ($result = mysqli_fetch_array($query)) {
                $output .= "<tr><td>{$result['username']}</td><td>{$result['cname']}</td><td>{$result['sname']}</td><td>{$result['cityname']}</td><td>{$result['pprice']}</td><td><img src='../images/" . "{$result['pimage1']}' /></td><td><img src='../images/" . "{$result['pimage2']}' /></td><td><img src='../images/" . "{$result['pimage3']}' /></td><td><img src='../images/" . "{$result['pimage4']}'/></td><td><img src='../images/" . "{$result['pimage5']}' /></td><td><img src='../images/" . "{$result['pimage6']}' /></td><td id='image_verified' ><button id='image-verification' onclick='image_verification(this.value)' value={$result['pid']} >Verify</button></td> <td id='dismiss_image' ><button  onclick='image_illegal(this.value)' value={$result['pid']} >dismiss</button></td>   </tr>";
        }
        $output .= "</table>";
        echo $output;
} else {
        echo "No Record Found";
}

//select username,ucountry,ustate,ucity,pprice,pimage1,pimage2,pimage3,pimage4,pimage5,pimage6 from register RIGHT OUTER JOIN user on register.id=user.registerid RIGHT OUTER JOIN product on user.userid=product.uid
