<?php
include("includes/config.php");
$productid = $_POST['product_id'];
$query = mysqli_query($con, "select * from product where pid='$productid'");
$result = mysqli_fetch_array($query);
$registerid = $result['registerid'];

$query = mysqli_query($con, "select * from register where id='$registerid'");
$result3 = mysqli_fetch_array($query);
$output = "<div class='owner_detail'>
           <center>";
$output .= "<div style='word-wrap: break-word;' id='owner_id' class='owner'>
          
          <span class='p_details' id='owner_picture's style='color: black;'>PRODUCT OWNER's PICTURE:</span><br>
          <img id='owner_pic'  src='{$result3["profilepic"]}' alt='owner_pix' /><br><br>
          <span class='p_details' id='owner_name' style='color: black;' >PRODUCT OWNER's NAME:</span>
          <span id='owner_orignal_name'>" . $result3['username'] . "</span><br><br>
          <span class='p_details' id='owner_cell_number' style='color: black;'>PRODUCT OWNER's CELL NUMBER:</span>
          <span  id='owner_orignal_cell_number'>" . $result['cellnumber'] . "</span><br><br>
          <span class='p_details' id='product_condition' style='color: black;'>PRODUCT CONDITION:</span>
          <span id='product_orignal_condition'>" . $result['con'] . "</span><br><br>
          <span class='p_details' id='product_title' style='color: black;'>PRODUCT TITLE:</span>
          <span id='product_orignal_title'>" . $result['ptitle'] . "</span><br><br>
          <span class='p_details' id='product_description' style='color: black;'>PRODUCT DESCRIPTION:</span>
          <span id='product_orignal_description'>" . $result['pdescription'] . "</span><br><br>
          </div>
          ";
$output .= "<div id='' class='owner'>
            <h1 id='product_img' style='color: black;'>Product Images</h1>
          <img style='display:block;display: block;
    height: 260px;
    width: 351px;
    box-sizing: border-box;
    padding: 5px;
    border: 1px solid gray;
    border-radius: 15px;
   margin-top:10px;
} ' id='owner_product_pic1' src='images/" . $result['pimage1'] . "' alt='owner_product_pix1' />
          <img style='display:block;display: block;
    height: 260px;
    width: 351px;
    box-sizing: border-box;
    padding: 5px;
    border: 1px solid gray;
    border-radius: 15px;
   margin-top:10px;
}' id='owner_product_pic2' src='images/" . $result['pimage2'] . "' alt='owner_product_pix2' />
          <img style='display:block;display: block;
    height: 260px;
    width: 351px;
    box-sizing: border-box;
    padding: 5px;
    border: 1px solid gray;
    border-radius: 15px;
   margin-top:10px; 
}'id='owner_product_pic3' src='images/" . $result['pimage3'] . "' alt='owner_product_pix3' />
          <img style='display:block;display: block;
    height: 260px;
    width: 351px;
    box-sizing: border-box;
    padding: 5px;
    border: 1px solid gray;
    border-radius: 15px;
   margin-top:10px;
}' id='owner_product_pic4' src='images/" . $result['pimage4'] . "' alt='owner_product_pix4' />
          <img style='display:block;display: block;
    height: 260px;
    width: 351px;
    box-sizing: border-box;
    padding: 5px;
    border: 1px solid gray;
    border-radius: 15px;
   margin-top:10px;
}' id='owner_product_pic5' src='images/" . $result['pimage5'] . "' alt='owner_product_pix5' />
          <img style='display:block;display: block;
    height: 260px;
    width: 351px;
    box-sizing: border-box;
    padding: 5px;
    border: 1px solid gray;
    border-radius: 15px;
   margin-top:10px; 
}' id='owner_product_pic6' src='images/" . $result['pimage6'] . "' alt='owner_product_pix6' />
          </div>
          </center>
          </div>";
echo $output;
