<?php
// session_start();
// print_r($_SESSION);
// print_r($_SESSION['username']);
// session_unset();
// session_destroy();
// die("here is some problem");

session_start();
if ((isset($_SESSION['ads'])) && (isset($_SESSION['foru']))) {
        echo "
<!DOCTYPE html>
<html lang='en'>

<head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Document</title>
        <style>
                body {
                        padding: 0px;
                        margin: 0px;
                        background-color: black;
                        color: white;
                }

                #congratulation_image {
                        display: block;
                        background-color: aliceblue;
                        height: 255px;
                        width: 301px;
                        /* padding-top: 30px; */
                        margin-top: 30px;
                        /* padding: 34px 0px;*/
                }

                #congratulation_msg {
                        font-size: 50px;
                        letter-spacing: 14.5px;
                        font-family: sans-serif;
                        color: bisque;
                }

                #successfully_text {
                        font-size: 27px;
                        letter-spacing: 2px;
                        padding: 5px;
                        color: bisque;
                }

                #enjoy_text {
                        padding: 5px;
                        font-size: 27px;
                        letter-spacing: 4px;
                        color: bisque;
                        font-family: monospace;
                }

                #ads_text {
                        font-size: 48px;
                        margin: 0px;
                        letter-spacing: 4px;
                        font-family: sans-serif;
                }

                #ads_text #ads {
                        color: rgba(213, 220, 218, 0.82);
                }

                #ads_text #for {
                        font-family: cursive;
                        color: rgb(255, 196, 245);
                }

                #ads_text #you {
                        color: rgb(191, 239, 236);
                }
        </style>
</head>

<body>
        <div id='congratulation_container'>
                <center>
                        <img id='congratulation_image' src='images/congratulation.png' alt='congratulation image'>
                        <h1 id='congratulation_msg'>CONGRATULATION</h1>
                        <h2 id='successfully_text'>YOU ARE REGISTERED SUCCESSFULLY</h2>
                        <h3 id='enjoy_text'>NOW ENJOY OUR WEBSITE</h3>
                        <h1 id='ads_text'><span id='ads'>ADS</span><span id='for'>4</span><span id='you'>U</span></h1>

                </center>
        </div>

</body>

</html>";
        echo "<script>
        setTimeout(function() {
                window.location.href = 'profile.php';
        }, 3000)
</script>";
} else {
        echo "
       <html>

<head>
        <style>
                body {
                        background-color: black;
                        color: white;
                        margin-top: 10px;
                        margin: 0px;
                        padding: 0px;
                }

                #welcome_pic {
                        border-radius: 13px;
                        margin-top: 19px;
                        width: 250px;
                        height: 265px;
                        background-color: white;
                }

                #dear {
                        font-size: 66px;
                        font-weight: bold;
                        letter-spacing: 10px;
                        font-family: monospace;
                }

                
               
        </style>
        <title>
                Welcome
        </title>
</head>

<body>
        <center>

                <img id='welcome_pic' src='images/error.png' alt='error' /><br>

                <label id='dear'>Dear:Please Registered Your Self First</label>
                


        </center>
</body>

</html>";
        echo "<script>
        setTimeout(function() {
                window.location.href = 'login.php';
        }, 3000)
</script>";
}
