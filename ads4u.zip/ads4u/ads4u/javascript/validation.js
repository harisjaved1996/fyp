let username_error = "your username must be between 5 and 25 characters";
let firstname_error = "your first name must be between 2 and 25 characters";
let lastname_error = "your last name must be between 2 and 25 characters";
let email_not_match = "Your email is not matching";
let email_invalid = "Your email is invalid";
let password_not_match = "your password is not matching";
let password_characters =
  "your password must contain between 5 and 25 characters";
let password_alphanumeric = "Your password must contain numbers and letters";
// let error_messages = [
//   { input_id: "username", value: username_error, error_id:"error_username" },
//   { input_id: "firstname", value: firstname_error, error_id:"error_firstname" },
//   { input_id: "lastname", value: lastname_error, error_id:"error_lastname" },
//   { input_id: "email", value: email_not_match, error_id:"error_email" },
//   { input_id: "email", value: email_invalid, error_id:"error_email" },
//   { input_id: "password", value: password_not_match, error_id:"error_password" },
//   { input_id: "password", value: password_characters, error_id:"error_password" },
//   { input_id: "password", value: password_alphanumeric, error_id:"error_" }
// ];
function validation(event) {
  let error_array = [];

  function validdate_username(username) {
    if (username.length > 25 || username.length < 5) {
      error_array.push(username_error);
      return;
    }
    return;
  }
  function validate_firstname(firstname) {
    if (firstname.length > 25 || firstname.length < 2) {
      error_array.push(firstname_error);
      return;
    }
    return;
  }
  function validate_lastname(lastname) {
    if (lastname.length > 25 || lastname.length < 2) {
      error_array.push(lastname_error);
      return;
    }
    return;
  }

  function validate_email(email, retypeemail, index_atrate, index_dot) {
    if (email != retypeemail) {
      error_array.push(email_not_match);
      return;
    } else if (
      index_atrate < 2 ||
      email.length - index_dot < 3 ||
      index_dot - index_atrate < 4
    ) {
      error_array.push(email_invalid);
      return;
    } else {
      return;
    }
  }
  function validate_password(password, retypepassword) {
    if (password != retypepassword) {
      error_array.push(password_not_match);
      return;
    } else if (password.length < 5 || password.length > 25) {
      error_array.push(password_characters);
      return;
    } else if (/[^0-9a-zA-z]/.test(password)) {
      error_array.push(password_alphanumeric);
      return;
    } else {
      return;
    }
  }

  //calling function from form

  let username = document.getElementById("username").value;

  let firstname = document.getElementById("firstname").value;

  let lastname = document.getElementById("lastname").value;

  let email = String(document.getElementById("email").value);

  let retypeemail = String(document.getElementById("retypeemail").value);

  let password = String(document.getElementById("password").value);

  let retypepassword = String(document.getElementById("retypepassword").value);

  let index_atrate = email.indexOf("@");
  let index_dot = email.lastIndexOf(".");
  event.preventDefault();

  validdate_username(username);
  validate_firstname(firstname);
  validate_lastname(lastname);
  validate_email(email, retypeemail, index_atrate, index_dot);
  validate_password(password, retypepassword);
  //   alert(error_array);
  //   for (let b of error_messages) {
  //     if (error_array.includes(b.value)) {
  //       document.getElementById(b.error_id).innerHTML = b.value;
  //     } else {
  //       document.getElementById(b.error_id).innerHTML = "";
  //     }
  //   }
  //   if (error_array.length > 0) {
  //     for (let b of error_messages) {
  //       if (error_array.includes(b.value)) {
  //         document.getElementById(b.input_id).focus();
  //         break;
  //       }
  //     }
  //   }
  // }
  if (error_array.includes(username_error)) {
    document.getElementById("error_username").innerHTML = username_error;
  } else {
    document.getElementById("error_username").innerHTML = "";
  }

  if (error_array.includes(firstname_error)) {
    document.getElementById("error_firstname").innerHTML = firstname_error;
  } else {
    document.getElementById("error_firstname").innerHTML = "";
  }

  if (error_array.includes(lastname_error)) {
    document.getElementById("error_lastname").innerHTML = lastname_error;
  } else {
    document.getElementById("error_lastname").innerHTML = "";
  }

  if (error_array.includes(email_not_match)) {
    document.getElementById("error_email").innerHTML = email_not_match;
  } else if (error_array.includes(email_invalid)) {
    document.getElementById("error_email").innerHTML = email_invalid;
  } else {
    document.getElementById("error_email").innerHTML = "";
  }
  if (error_array.includes(password_not_match)) {
    document.getElementById("error_password").innerHTML = password_not_match;
  } else if (error_array.includes(password_characters)) {
    document.getElementById("error_password").innerHTML = password_characters;
  } else if (error_array.includes(password_alphanumeric)) {
    document.getElementById("error_password").innerHTML = password_alphanumeric;
  } else {
    document.getElementById("error_password").innerHTML = "";
  }
  if (error_array.length != 0) {
    if (error_array.includes(username_error)) {
      document.getElementById("username").focus();
    } else if (error_array.includes(firstname_error)) {
      document.getElementById("firstname").focus();
    } else if (error_array.includes(lastname_error)) {
      document.getElementById("lastname").focus();
    } else if (error_array.includes(email_not_match)) {
      document.getElementById("email").focus();
    } else if (error_array.includes(email_invalid)) {
      document.getElementById("email").focus();
    } else if (error_array.includes(password_not_match)) {
      document.getElementById("password").focus();
    } else if (error_array.includes(password_characters)) {
      document.getElementById("password").focus();
    } else if (error_array.includes(password_alphanumeric)) {
      document.getElementById("password").focus();
    }
  } else {
    setTimeout(() => {
      event.target.submit();
    }, 3000);
  }

  // if (error_array.length != 0) {

  //   if (error_array.includes(username_error)) {
  //     alert("username");
  //     document.getElementById("username").focus();
  //   }
  // else if (error_array.includes(firstname_error)) {
  //   CustomElementRegistry("firstname");
  //   document.getElementById("firstname").focus();
  //   }
  // else if (error_array.includes(lastname_error)) {
  //   alert("lastname");
  //   document.getElementById("lastname").focus();
  //    }
  //else if (error_array.includes(email_not_match)) {
  //     document.getElementById("error_email").focus();
  //     break;
  //   } else if (error_array.includes(email_invalid)) {
  //     document.getElementById("error_email").focus();
  //     break;
  //   } else if (error_array.includes(password_not_match)) {
  //     document.getElementById("error_password").focus();
  //     break;
  //   } else if (error_array.includes(password_characters)) {
  //     document.getElementById("error_password").focus();
  //     break;
  //   } else {
  //     if (error_array.includes(password_alphanumeric)) {
  //       document.getElementById("error_password").focus();
  //       break;
  //     }
  //}
  // } else {
  //   setTimeout(() => {
  //     event.target.submit();
  //   }, 5000);
  // }

  // for (let a of error_array) {
  //   if (a.includes(username_error)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(username_error)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else if (a.includes(firstname_error)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(firstname_error)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else if (a.includes(lastname_error)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(lastname_error)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else if (a.includes(email_not_match)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(email_not_match)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else if (a.includes(email_invalid)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(email_invalid)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else if (a.includes(password_not_match)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(password_not_match)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else if (a.includes(password_characters)) {
  //     for (let b of error_messages) {
  //       if (b.value.includes(password_characters)) {
  //         document.getElementById(b.id).focus();
  //         break;
  //       }
  //     }
  //   } else {
  //     if (a.includes(password_alphanumeric)) {
  //       for (let b of error_messages) {
  //         if (b.value.includes(password_alphanumeric)) {
  //           document.getElementById(b.id).focus();
  //           break;
  //         }
  //       }
  //     }
  //   }
  // }

  //alert(error_messages);
  //alert(error_array);
  // let unique_array = [];
  // for (let i of error_messages) {
  //   for (j of error_array) {
  //     if (i.value == j) {
  //       document.getElementById(i.id).innerHTML = i.value;
  //     } else {
  //       if (unique_array.indexOf(i.id) < 0) {
  //         unique_array.push(i.id);
  //       }
  //     }
  //   }
  // }
  // alert(unique_array);

  // for (let a of unique_array) {
  //   document.getElementById(a).innerHTML = "";
  // }
}
//}
