const inpFile = document.getElementById("file");
const previewContainer = document.getElementById("imagePreiew");
const previewImage = previewContainer.querySelector(".image-preview__image");
const previewDefaultTExt = previewContainer.querySelector(
  ".image-preview__default-text"
);
inpFile.addEventListener("change", function () {
  const file = this.files[0];
  console.log(file);
  if (file) {
    const reader = new FileReader();
    previewDefaultTExt.style.display = "none";
    previewImage.style.display = "block";
    reader.addEventListener("load", function () {
      previewImage.setAttribute("src", this.result);
    });
    reader.readAsDataURL(file);
  } else {
    previewDefaultTExt.style.display = null;
    previewImage.style.display = null;
    previewImage.setAttribute("src", "");
  }
});
