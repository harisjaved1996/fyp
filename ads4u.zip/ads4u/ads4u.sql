-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2020 at 07:49 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ads4u`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `vkey` int(11) NOT NULL,
  `verified` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `firstname`, `lastname`, `email`, `password`, `vkey`, `verified`) VALUES
(37, 'admin', 'admin', 'admin@yahoo.com', '$2y$10$bZf53yI8NawsullUjNjk2Oax9j7OstnG1fw9htgSa.mPb7enRQGbe', 761747, 1),
(38, 'admin', 'admin', 'admin1122@yahoo.com', '$2y$10$bhDjxLVwcOougQfdjDzSye1sHd3yrZ25NryujdZIbcrWu49IfJOmK', 468600, 1),
(39, 'haris', 'javed', 'harisjaved@yahoo.com', '$2y$10$tAUpf0k7PZGfiADwvHZuIevCjFzBfEBoeGXEkP93GhmF4sBDbfMRO', 419619, 1),
(40, 'haris', 'javed', 'harisjaved1@yahoo.com', '$2y$10$0fZNssT1yJu0P87/MBgcCOW9zYfb/0Eh4Yq4zAXr8kc4y00eb5rHe', 594638, 1),
(41, 'haris', 'javed', 'harisjaved1122@yahoo.com', '$2y$10$XHlr6vS23AnnaXQZ5K3DN.9OFbermS5wcGnmWsyloJlP4ToWXsYw.', 933385, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catid` int(11) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catid`, `category`) VALUES
(42, 'mobile'),
(43, 'vehicles'),
(44, 'propertyforrent'),
(45, 'propertyforsale');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `registerid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `subcatid` int(11) NOT NULL,
  `con` varchar(20) NOT NULL,
  `ptitle` varchar(100) NOT NULL,
  `pdescription` varchar(2000) NOT NULL,
  `pprice` varchar(20) NOT NULL,
  `pimage1` varchar(100) NOT NULL,
  `pimage2` varchar(100) NOT NULL,
  `pimage3` varchar(100) NOT NULL,
  `pimage4` varchar(100) NOT NULL,
  `pimage5` varchar(100) NOT NULL,
  `pimage6` varchar(100) NOT NULL,
  `verified` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `uid`, `registerid`, `catid`, `subcatid`, `con`, `ptitle`, `pdescription`, `pprice`, `pimage1`, `pimage2`, `pimage3`, `pimage4`, `pimage5`, `pimage6`, `verified`) VALUES
(90, 58, 139, 42, 65, 'new', 'samsung galaxy ', 'asjndja sdjasndjasd', '12000', '5f2d9086c738d.jpg', '5f2d9086c7795.jpg', '5f2d9086c7aac.jpg', '5f2d9086c7e7f.jpg', '5f2d9086c8340.jpg', '5f2d9086c8680.jpg', 1),
(91, 59, 139, 42, 66, 'new', 'oppo a37', 'asdbbasdb bsadasd sadbas', '123999', '5f2d912024fc7.jpg', '5f2d9120253c9.jpg', '5f2d912025846.jpg', '5f2d912025c49.jpg', '5f2d912026001.jpg', '5f2d912026307.jpg', 1),
(92, 58, 139, 42, 67, 'new', 'samsung', 'asdjsadij dajsidjiasd sajdijsa', '12000', '5f30bfd2e9c8f.png', '5f30bfd2f3813.png', '5f30bfd2f3c71.png', '5f30bfd2f4098.png', '5f30bfd300220.png', '5f30bfd30063b.png', 0),
(93, 60, 139, 43, 68, 'new', 'asdsad', 'dsfsdf sfdsfdsf sdfsd', '233223', '5f30c023dedf3.jpg', '5f30c023df1b8.jpg', '5f30c023df5d9.jpg', '5f30c023df9c1.jpg', '5f30c023dfdeb.jpg', '5f30c023e01c4.jpg', 0),
(94, 61, 139, 44, 69, 'new', 'werewwerwe', 'safsdf fsdfgd gfd gfdgfd', '34543534', '5f30c0d0393ba.PNG', '5f30c0d039787.PNG', '5f30c0d039ba2.PNG', '5f30c0d039fab.PNG', '5f30c0d03a39f.PNG', '5f30c0d03a8b3.PNG', 0),
(95, 58, 139, 45, 70, 'used', 'dsfsdfdsfdsfsd', 'dsjfk sdjfkjsdkfsdk', '23432423', '5f30c1142a390.PNG', '5f30c11438840.PNG', '5f30c11438c9c.PNG', '5f30c114391df.PNG', '5f30c11439605.PNG', '5f30c114399f8.PNG', 0),
(96, 58, 139, 44, 69, 'new', 'werewwerwe', 'sfdds df dsfdsf sdfsd', '3434334', '5f30c60366a45.jpg', '5f30c60366f92.jpg', '5f30c603673bf.jpg', '5f30c60367a53.jpg', '5f30c60367fba.jpg', '5f30c603683c1.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(60) NOT NULL,
  `signupdate` datetime NOT NULL,
  `profilepic` varchar(500) NOT NULL,
  `vkey` int(6) NOT NULL,
  `verified` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `firstname`, `lastname`, `email`, `password`, `signupdate`, `profilepic`, `vkey`, `verified`) VALUES
(139, 'hjaved', 'Haris', 'Javed', 'Mharis.javed1996@gmail.com', '$2y$10$14xDNppN0AaaOAvWM83P6Of2B42JFU4LiWNE18sXqw5PY6nWzazY.', '2020-08-07 10:12:39', 'images/mypix.jpg', 377916, 1),
(140, 'aqibmehmood', '123456', 'Mehmood', 'Mehmood7455@gmail.com', '$2y$10$iXjtynkLIdMEDMoZPjmd1eMdWMwQfOrFM8kLRRu271x8H3XRikT/a', '2020-08-07 10:49:11', 'images/baby.jpg', 393765, 0);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `subcatid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `subcategory` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcatid`, `catid`, `subcategory`) VALUES
(65, 42, 'tablets'),
(66, 42, 'mobilephones'),
(67, 42, 'accessories'),
(68, 43, 'carsaccessories'),
(69, 44, 'portionsfloors1'),
(70, 45, 'apartmetsplots');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `registerid` int(11) NOT NULL,
  `ucountry` varchar(60) NOT NULL,
  `ustate` varchar(60) NOT NULL,
  `ucity` varchar(60) NOT NULL,
  `ucellnumber` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `registerid`, `ucountry`, `ustate`, `ucity`, `ucellnumber`) VALUES
(58, 139, 'pakistan', 'punjab', 'multan', '+923013806559'),
(59, 139, 'pakistan', 'sindh', 'karachi', '+923013806559'),
(60, 139, 'pakistan', 'dsffsdfsdfsd', 'dsfsdfsdfsd', '+923013806559'),
(61, 139, 'pakistan', 'fdfgfdg', 'fgfdgfdgfdgfd', '+923157960589');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`subcatid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `subcatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
